<?php
$pageTitle = "Sudeste Asiático | El Viejo Viajero";
include __DIR__ . "/../../includes/header.php";
?>
<div class="cover-hero">
  <div class="container">
    <div class="box" style="height:180px;border-radius:16px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;letter-spacing:.5px;font-size:1.6rem;background-image:linear-gradient(135deg,#6BAF4D,#6BAF4D)">Sudeste Asiático</div>
  </div>
</div>
<div class="container page-head">
  <h1 style="color:var(--brand)">Sudeste Asiático</h1>
  <p class="page-sub">Tailandia, Vietnam, Bali… mezclas perfectas de cultura y playa.</p>
</div>
<section class="section">
  <div class="container">
    <h2>Qué preparo para ti</h2>
    <div class="box-note"><ul>
      <li>Ruta por países/zonas con vuelos internos</li>
      <li>Hoteles bien ubicados (calidad/precio)</li>
      <li>Excursiones reales (no turistada)</li>
      <li>Trucos de cambio, SIM, taxis y comidas</li>
    </ul></div>
  </div>
</section>
<section class="section">
  <div class="container">
    <h2>Cómo lo haremos</h2>
    <div class="box-note"><ol>
      <li>Me cuentas origen, fechas, personas y presupuesto.</li>
      <li>Te digo los días recomendados y envío propuesta base.</li>
      <li>La afinamos juntos y gestiono reservas si quieres.</li>
      <li>Recibes tu guía final + soporte por WhatsApp.</li>
    </ol></div>
    <div class="cta-end">
      <a class="btn" href="/contacto.php">Contáctanos</a>
      <a class="btn alt" href="https://wa.me/34614451169" rel="noopener" target="_blank">Háblanos por WhatsApp</a>
    </div>
  </div>
</section>
<?php include __DIR__ . "/../../includes/footer.php"; ?>
