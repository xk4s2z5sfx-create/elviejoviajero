<?php
$pageTitle = "Berlín Navidad | El Viejo Viajero";
include __DIR__ . "/../../includes/header.php";
?>
<div class="cover-hero">
  <div class="container">
    <div class="box" style="height:180px;border-radius:16px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;letter-spacing:.5px;font-size:1.6rem;background-image:linear-gradient(135deg,#1E4D3B,#1E4D3B)">Berlín Navidad</div>
  </div>
</div>
<div class="container page-head">
  <h1 style="color:var(--brand)">Berlín Navidad</h1>
  <p class="page-sub">Mercados, luces y clásicos imprescindibles. Ideal en pareja.</p>
</div>
<section class="section">
  <div class="container">
    <h2>Itinerario sugerido</h2>
    <div class="box-note"><ul>
      <li>Día 1: llegada y paseo por centro histórico</li>
      <li>Día 2: Muro + Mitte + mercados</li>
      <li>Día 3: Charlottenburg + Ku'damm</li>
      <li>Día 4: cultura y tiempo libre</li>
    </ul></div>
  </div>
</section>
<section class="section">
  <div class="container">
    <h2>Qué incluye mi planificación</h2>
    <div class="box-note"><ul>
      <li>Diseño de ruta 100% personalizada.</li>
      <li>Recomendación y gestión de reservas (vuelos, hotel y actividades).</li>
      <li>Documento final bonito (HTML/PDF) por días con mapas y enlaces.</li>
      <li>Soporte por WhatsApp antes y durante el viaje.</li>
      <li>Mapa guardado con puntos clave y transporte.</li>
      <li>Checklist previa y consejos prácticos.</li>
      <li>Ajustes razonables de última hora.</li>
      <li>Trato directo conmigo, sin chatbots.</li>
    </ul></div>
  </div>
</section>
<section class="section">
  <div class="container">
    <h2>Cómo funciona</h2>
    <div class="box-note"><ul>
      <li>Me cuentas origen, fechas, nº de personas y presupuesto.</li>
      <li>Te envío propuesta base y la afinamos juntos.</li>
      <li>Confirmamos reservas y cierro el plan día a día.</li>
      <li>Recibes tu guía final + soporte por WhatsApp.</li>
    </ul></div>
  </div>
</section>
<?php include __DIR__ . "/../../includes/footer.php"; ?>
