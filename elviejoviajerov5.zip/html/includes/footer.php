</main>
<footer class="footer">
  © <span id="y"></span> El Viejo Viajero · Hecho a mano.
</footer>
<script>document.getElementById('y').textContent = new Date().getFullYear();</script>
</body>
</html>
