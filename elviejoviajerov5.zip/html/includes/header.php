<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width,initial-scale=1" name="viewport"/>
  <title><?= $pageTitle ?? 'El Viejo Viajero'; ?></title>
  <meta name="theme-color" content="#1E4D3B">
  <meta name="description" content="Viajes personalizados: Camino de Santiago, escapadas por Europa, Nueva York, Japón y Sudeste Asiático. Organizamos viajes únicos y adaptados a ti.">
  <link rel="icon" href="/logo.PNG" type="image/png">
  <link rel="apple-touch-icon" href="/logo.PNG">
  <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<header class="evv-onebar">
  <div class="onebar-inner">
    <a aria-label="Inicio" class="brand" href="/">
      <img alt="El Viejo Viajero" class="brand-logo" src="/assets/logo.PNG"/>
      <span class="brand-title">El Viejo Viajero</span>
    </a>
    <a class="btn-cta" href="/contacto.php">Contáctanos</a>
  </div>
</header>
<main>
