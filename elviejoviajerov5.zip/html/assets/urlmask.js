
// urlmask.js — Si no estás en /admin, fuerza mostrar "/" en la barra sin recargar
(function(){
  try{
    if (!location.pathname.startsWith('/admin')) {
      if (location.pathname !== '/') {
        history.replaceState(null, '', '/');
      }
    }
  }catch(e){}
})();
