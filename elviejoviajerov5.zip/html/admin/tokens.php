
<?php
session_start();
if (empty($_SESSION['evv_admin'])) { header('Location: /admin/index.php'); exit; }
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Admin · Reseñas · Tokens</title>
  <style>
    :root{--ink:#1c2a27;--muted:#5f6e6a;--bg:#faf9f5;--brand:#1E4D3B;--accent:#C47A3C}
    *{box-sizing:border-box} html,body{margin:0;padding:0}
    body{font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; background:var(--bg); color:var(--ink)}
    .container{max-width:1100px; margin:0 auto; padding:0 18px}
    h1{color:var(--brand)}
    .row{display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin:10px 0}
    .row input{padding:10px 12px; border:1px solid #e5e5e5; border-radius:10px; font-size:1rem}
    table{width:100%; border-collapse:collapse; margin-top:12px}
    th,td{border:1px solid #eee; padding:8px; text-align:left; vertical-align:top}
    .btn{display:inline-block; background:var(--brand); color:#fff; padding:10px 14px; border-radius:10px; font-weight:700; cursor:pointer}
    .btn.alt{background:var(--accent)} .btn.warn{background:#9b1c1c}
    .status{margin-left:8px; font-size:.9rem; color:#5f6e6a}
    .ok{color:#1E4D3B} .fail{color:#9b1c1c}
  </style>
</head>
<body>
  <div class="container">
    <h1>Tokens de reseñas (privado)</h1>
    <div class="row">
      <button class="btn" id="reload">Cargar desde servidor</button>
      <button class="btn" id="save">Guardar en servidor</button>
      <button class="btn alt" id="download">Descargar review_tokens.json</button>
      <a class="btn alt" href="/admin/home.php">← Volver al panel</a>
      <span id="st" class="status"></span>
    </div>
    <div class="row">
      <input id="ref" placeholder="ID reserva / Nombre cliente" style="min-width:260px">
      <input id="email" placeholder="Email del cliente" style="min-width:260px" type="email">
      <label style="display:flex;align-items:center;gap:6px"><input type="checkbox" id="once"> Un solo uso</label>
      <button class="btn" id="gen">Generar token</button>
    </div>
    <table id="tbl">
      <thead><tr><th>Ref</th><th>Email</th><th>Token</th><th>Uso único</th><th>Enlace</th><th>Acciones</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>
  <script>
    let data={tokens:[]}; const st=document.getElementById('st'); const tbody=document.querySelector('#tbl tbody');
    function rnd(n){const ch='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';let s='';for(let k=0;k<n;k++){s+=ch[Math.floor(Math.random()*ch.length)];}return s;}
    function linkFor(t){ return location.origin + '/opiniones/index.php?t=' + t.token; }
    function render(){ tbody.innerHTML = data.tokens.map((t,i)=>`
      <tr>
        <td><input data-i="${i}" data-k="ref" value="${t.ref||''}"/></td>
        <td><input data-i="${i}" data-k="email" value="${t.email||''}" type="email"/></td>
        <td><code>${t.token}</code></td>
        <td><input type="checkbox" data-i="${i}" data-k="once" ${t.once?'checked':''}/></td>
        <td><input value="${linkFor(t)}" style="width:100%"/></td>
        <td>
          <button class="btn send" data-i="${i}">Enviar por correo</button>
          <button class="btn warn del" data-i="${i}">Borrar</button>
        </td>
      </tr>`).join(''); }

    async function load(){ try{ const r=await fetch('/api/load_tokens.php'); const j=await r.json(); data=j||{tokens:[]}; render(); st.textContent='Cargado'; st.className='status ok'; setTimeout(()=>st.textContent='',1400);}catch(e){ st.textContent='Error cargando'; st.className='status fail'; }}
    async function save(){ try{ const b=new FormData(); b.append('payload', JSON.stringify(data)); const r=await fetch('/api/save_tokens.php',{method:'POST',body:b}); const t=await r.text(); if(t.trim().startsWith('OK')){ st.textContent='Guardado'; st.className='status ok'; setTimeout(()=>st.textContent='',1200);} else { st.textContent='Error guardando'; st.className='status fail'; } }catch(e){ st.textContent='Error de red'; st.className='status fail'; } }

    document.getElementById('gen').onclick=()=>{
      const ref=document.getElementById('ref').value.trim();
      const email=document.getElementById('email').value.trim();
      if(!ref){ alert('Introduce la referencia / nombre del cliente'); return; }
      if(!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ alert('Introduce un email válido'); return; }
      const once=document.getElementById('once').checked;
      data.tokens.push({ref, email, token:rnd(24), once});
      render(); save();
      document.getElementById('ref').value=''; document.getElementById('email').value=''; document.getElementById('once').checked=false;
    };

    document.getElementById('reload').onclick=()=>load();
    document.getElementById('save').onclick=()=>save();
    document.getElementById('download').onclick=()=>{ const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='review_tokens.json'; a.click(); };

    tbody.addEventListener('click', async (e)=>{
      if(e.target.classList.contains('del')){
        const i=parseInt(e.target.getAttribute('data-i')); data.tokens.splice(i,1); render(); save(); return;
      }
      if(e.target.classList.contains('send')){
        const i=parseInt(e.target.getAttribute('data-i')); const t=data.tokens[i]; const btn=e.target; btn.disabled=true; const prev=btn.textContent; btn.textContent='Enviando…';
        const body=new FormData(); body.append('to', t.email); body.append('link', linkFor(t)); body.append('name', t.ref||''); body.append('token', t.token);
        const r = await fetch('/api/send_token.php',{method:'POST',body,credentials:'include'}); const txt=await r.text();
        if(txt.trim().startsWith('OK')){ btn.textContent='📧 Enviado'; } else { btn.textContent='⚠️ Error'; console.log('send error:', txt); }
        setTimeout(()=>{ btn.disabled=false; btn.textContent=prev; }, 1800);
      }
    });

    tbody.addEventListener('input', e=>{
      const i=e.target.getAttribute('data-i'); const k=e.target.getAttribute('data-k'); if(i==null||!k) return;
      let v = (e.target.type==='checkbox') ? e.target.checked : e.target.value; data.tokens[parseInt(i)][k]=v; save();
    });

    load();
  </script>
</body>
</html>
