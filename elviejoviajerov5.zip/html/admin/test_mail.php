
<?php
// Envía un correo de prueba para verificar mail() en el servidor.
$to = isset($_GET['to']) ? $_GET['to'] : 'hola@elviejoviajero.es';
$subject = "Prueba mail() IONOS - El Viejo Viajero";
$body = "Este es un mensaje de prueba enviado desde admin/test_mail.php a las ".date('c');
$headers = [];
$headers[] = "From: El Viejo Viajero <noreply@elviejoviajero.es>";
$headers[] = "Content-Type: text/plain; charset=UTF-8";
$envelope = "-f noreply@elviejoviajero.es";
$ok = @mail($to, '=?UTF-8?B?'.base64_encode($subject).'?=', $body, implode("\r\n", $headers), $envelope);
echo $ok ? "OK enviado a $to" : "ERROR enviando";
