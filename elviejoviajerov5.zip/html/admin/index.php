
<?php
// admin/index.php — login
session_start();
require_once __DIR__ . '/../api/admin_secrets.php';

// Si ya está logueado, a home
if (!empty($_SESSION['evv_admin']) && $_SESSION['evv_admin'] === true) {
  header('Location: /admin/home.php'); exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $u = trim($_POST['user'] ?? '');
  $p = trim($_POST['pass'] ?? '');
  if ($u === $ADMIN_USER && password_verify($p, $ADMIN_PASS_BCRYPT)) {
    $_SESSION['evv_admin'] = true;
    header('Location: /admin/home.php'); exit;
  } else {
    $error = 'Usuario o contraseña incorrectos';
  }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Acceso admin | El Viejo Viajero</title>
  <style>
    :root{--ink:#1c2a27;--muted:#5f6e6a;--bg:#faf9f5;--card:#ffffff;--brand:#1E4D3B;--accent:#C47A3C}
    *{box-sizing:border-box} html,body{margin:0;padding:0}
    body{font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; background:var(--bg); color:var(--ink)}
    .wrap{min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px}
    .card{background:#fff; border:1px solid #eee; border-radius:16px; padding:24px; width:100%; max-width:420px}
    h1{margin:0 0 12px; color:var(--brand)}
    .input{display:flex; flex-direction:column; gap:6px; margin:10px 0}
    .input input{padding:12px 12px; border:1px solid #e5e5e5; border-radius:10px; font-size:1rem}
    .btn{display:inline-block; background:var(--brand); color:#fff; padding:12px 16px; border-radius:12px; font-weight:700; cursor:pointer; border:0}
    .err{display:<?php echo $error?'block':'none'; ?>; background:#fdecea; border:1px solid #f5c2c7; color:#7a1f28; padding:10px; border-radius:10px; margin-top:8px}
    .hint{color:var(--muted); font-size:.95rem; margin-top:10px}
  </style>
</head>
<body>
  <div class="wrap">
    <form class="card" method="post" action="/admin/index.php">
      <h1>Acceso admin</h1>
      <div class="input">
        <label>Usuario</label>
        <input name="user" required autocomplete="username">
      </div>
      <div class="input">
        <label>Contraseña</label>
        <input name="pass" type="password" required autocomplete="current-password">
      </div>
      <button class="btn" type="submit">Entrar</button>
      <div class="err"><?php echo htmlspecialchars($error); ?></div>
      <div class="hint">¿Olvidaste la clave? Edita <code>/api/admin_secrets.php</code> en el servidor para cambiarla.</div>
    </form>
  </div>
</body>
</html>
