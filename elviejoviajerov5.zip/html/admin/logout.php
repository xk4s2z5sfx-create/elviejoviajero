
<?php
// admin/logout.php — cierra sesión y vuelve al login
session_start();
$_SESSION = [];
session_destroy();
header('Location: /admin/index.php');
exit;
