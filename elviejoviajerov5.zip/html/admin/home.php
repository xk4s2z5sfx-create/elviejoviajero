
<?php
session_start();
if (empty($_SESSION['evv_admin'])) { header('Location: /admin/index.php'); exit; }
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Admin · Panel | El Viejo Viajero</title>
  <style>
    :root{--ink:#1c2a27;--muted:#5f6e6a;--bg:#faf9f5;--card:#ffffff;--brand:#1E4D3B;--accent:#C47A3C}
    *{box-sizing:border-box} html,body{margin:0;padding:0}
    body{font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; background:var(--bg); color:var(--ink)}
    .container{max-width:1100px; margin:0 auto; padding:0 18px}
    .topbar{background:#fff; border-bottom:1px solid #ececec}
    .topbar .inner{max-width:1100px; margin:0 auto; padding:14px 18px; display:flex; align-items:center; justify-content:space-between}
    .brand{display:flex; align-items:center; gap:10px; color:var(--brand); font-weight:800}
    .brand .dot{width:18px; height:18px; border-radius:50%; background:var(--brand)}
    .btn{display:inline-block; background:var(--brand); color:#fff; padding:10px 14px; border-radius:10px; font-weight:700; cursor:pointer; text-decoration:none}
    .btn.alt{background:var(--accent)}
    h1{color:var(--brand)}
    .grid{display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:18px; margin-bottom:40px}
    .card{display:flex; flex-direction:column; justify-content:space-between; min-height:170px; background:#fff; border:1px solid #eee; border-radius:14px; padding:18px}
    .card h3{margin:0 0 8px 0; color:var(--ink)}
    .card p{margin:0 0 16px 0; color:var(--muted)}
    footer{color:var(--muted); font-size:.9rem; padding:24px 18px 40px}
    footer .inner{max-width:1100px; margin:0 auto;}
    a{color:var(--brand)}
  </style>
</head>
<body>
  <header class="topbar">
    <div class="inner">
      <div class="brand"><span class="dot"></span> El Viejo Viajero · Admin</div>
      <nav>
        <a class="btn alt" href="/admin/logout.php" title="Cerrar sesión">Cerrar sesión</a>
      </nav>
    </div>
  </header>

  <main class="container">
    <h1>Herramientas</h1>
    <div class="grid">
      <div class="card">
        <div>
          <h3>Reseñas · Moderación</h3>
          <p>Aprueba o rechaza las reseñas recibidas.</p>
        </div>
        <a class="btn" href="/admin/resenas.php">Abrir</a>
      </div>
      <div class="card">
        <div>
          <h3>Reseñas · Tokens</h3>
          <p>Genera y envía enlaces seguros de reseña.</p>
        </div>
        <a class="btn" href="/admin/tokens.php">Abrir</a>
      </div>
      <div class="card">
        <div>
          <h3>Viajes vendidos</h3>
          <p>Registra ventas y activa recordatorios automáticos.</p>
        </div>
        <a class="btn" href="/admin/bookings.php">Abrir</a>
      </div>
    </div>
  </main>

  <footer>
    <div class="inner">© <?php echo date('Y'); ?> El Viejo Viajero · Panel privado</div>
  </footer>
</body>
</html>
