
<?php
session_start();
if (empty($_SESSION['evv_admin'])) { header('Location: /admin/index.php'); exit; }
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Admin · Moderar reseñas | El Viejo Viajero</title>
  <style>
    :root{--ink:#1c2a27;--muted:#5f6e6a;--bg:#faf9f5;--card:#ffffff;--brand:#1E4D3B;--accent:#C47A3C}
    *{box-sizing:border-box} html,body{margin:0;padding:0}
    body{font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; background:var(--bg); color:var(--ink)}
    .container{max-width:1100px; margin:0 auto; padding:0 18px}
    h1{color:#1E4D3B}
    table{width:100%; border-collapse:collapse; margin-top:12px}
    th,td{border:1px solid #eee; padding:10px; vertical-align:top}
    .btn{display:inline-block; background:#1E4D3B; color:#fff; padding:8px 12px; border-radius:10px; font-weight:700; cursor:pointer; margin-right:6px}
    .btn.alt{background:#C47A3C}
    .btn.warn{background:#9b1c1c}
    .tag{display:inline-block; padding:2px 8px; border-radius:8px; background:#eaf1ed; color:#1E4D3B; font-weight:700; font-size:.85rem}
    .row{display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin:10px 0}
    .status{margin-left:8px; font-size:.9rem; color:#5f6e6a}
    .ok{color:#1E4D3B} .fail{color:#9b1c1c}
  </style>
</head>
<body>
  <div class="container">
    <h1>Moderar reseñas</h1>
    <p>Solo se muestran en la web las reseñas <strong>aprobadas</strong>. Aprueba o rechaza y se guardará automáticamente.</p>
    <div class="row">
      <button id="reload" class="btn">Cargar desde servidor</button>
      <span id="st" class="status"></span>
      <a class="btn alt" href="/admin/home.php">← Volver al panel</a>
    </div>
    <table id="tbl">
      <thead><tr><th>#</th><th>Autor</th><th>Texto</th><th>Fecha</th><th>Estado</th><th>Acciones</th></tr></thead>
      <tbody></tbody>
    </table>
  </div>

  <script>
    let data={reviews:[]};
    const tbody=document.querySelector('#tbl tbody');
    const st=document.getElementById('st');

    async function loadServer(){
      try{
        const r = await fetch('/data/reviews.json'); const j = await r.json();
        data = j && j.reviews ? j : {reviews:[]}; render();
        st.textContent='Cargado del servidor'; st.className='status ok'; setTimeout(()=>st.textContent='',1500);
      }catch(err){ st.textContent='No se pudo cargar del servidor'; st.className='status fail'; }
    }
    async function saveServer(showToast=true){
      try{
        const body = new FormData();
        body.append('payload', JSON.stringify(data));
        const r = await fetch('/api/mod_reviews.php', {method:'POST', body});
        const t = await r.text();
        if (t.trim().toLowerCase().includes('guardado')){
          if(showToast){ st.textContent='Guardado'; st.className='status ok'; setTimeout(()=>st.textContent='',1000); }
        } else {
          if(showToast){ st.textContent='Error guardando: '+t; st.className='status fail'; }
        }
      }catch(err){ if(showToast){ st.textContent='Error de red al guardar'; st.className='status fail'; } }
    }

    function render(){
      tbody.innerHTML = data.reviews.map((r,i)=>`
        <tr>
          <td>${i+1}</td>
          <td><input data-i="${i}" data-k="author" value="${(r.author||'').replaceAll('"','&quot;')}" style="width:160px"></td>
          <td><textarea data-i="${i}" data-k="text" rows="4" style="width:100%">${(r.text||'').replaceAll('<','&lt;')}</textarea></td>
          <td>${r.date||''}</td>
          <td>${r.pending?'<span class="tag">Pendiente</span>':'Aprobada'}</td>
          <td>
            <button class="btn" data-approve="${i}">Aprobar</button>
            <button class="btn warn" data-reject="${i}">Rechazar</button>
          </td>
        </tr>
      `).join('');
    }

    tbody.addEventListener('click', async e=>{
      const a=e.target.getAttribute('data-approve');
      const rj=e.target.getAttribute('data-reject');
      if(a!=null){
        data.reviews[parseInt(a)].pending=false; render();
        await saveServer();
      }
      if(rj!=null){
        data.reviews.splice(parseInt(rj),1); render();
        await saveServer();
      }
    });

    let tmr=null;
    function queuedSave(){ if(tmr){ clearTimeout(tmr); } tmr=setTimeout(()=>saveServer(false), 700); }
    tbody.addEventListener('input', e=>{
      const i=e.target.getAttribute('data-i'); const k=e.target.getAttribute('data-k');
      if(i!=null && k){ data.reviews[parseInt(i)][k]=e.target.value; queuedSave(); }
    });

    document.getElementById('reload').onclick=()=>loadServer();
    loadServer();
  </script>
</body>
</html>
