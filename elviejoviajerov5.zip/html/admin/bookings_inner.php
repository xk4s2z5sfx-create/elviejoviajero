<?php
session_start();
if (empty($_SESSION['evv_admin'])) { header('Location: /admin/index.php'); exit; }
?><!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Admin · Viajes / Seguimiento y reseñas | El Viejo Viajero</title>
  <style>
    :root{--ink:#1c2a27;--muted:#5f6e6a;--bg:#faf9f5;--brand:#1E4D3B;--accent:#C47A3C;--card:#ffffff;--line:#e8e6e0}
    *{box-sizing:border-box} html,body{margin:0;padding:0}
    body{font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; background:var(--bg); color:var(--ink)}
    .container{max-width:1200px; margin:0 auto; padding:0 18px 40px}
    h1{color:var(--brand); margin:18px 0}
    .actions-top{display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin:10px 0}
    .card{background:var(--card); border:1px solid var(--line); border-radius:14px; padding:14px 14px 16px; box-shadow:0 1px 0 rgba(0,0,0,.02); margin:12px 0}
    .card h2{font-size:1.05rem; margin:0 0 10px; color:var(--brand)}
    .grid{display:grid; gap:10px}
    .grid.filters{grid-template-columns:1fr}
    .grid.newtrip{grid-template-columns:repeat(6,minmax(0,1fr))}
    @media (max-width: 980px){ .grid.newtrip{grid-template-columns:repeat(2, minmax(0,1fr));} }
    .field{display:flex; flex-direction:column; gap:6px}
    .label{font-size:.9rem; color:var(--muted)}
    input, select{padding:10px 12px; border:1px solid #e5e5e5; border-radius:10px; font-size:1rem; background:#fff}
    .btn{display:inline-block; background:var(--brand); color:#fff; padding:10px 14px; border-radius:10px; font-weight:700; cursor:pointer; border:0}
    .btn.alt{background:var(--accent)} .btn.warn{background:#9b1c1c}
    .btn-ghost{border:1px solid #d7dfd9; padding:.4rem .7rem; border-radius:.6rem; background:#f7faf8; cursor:pointer; font-weight:600;}
    .btn-ghost[disabled]{ opacity:.6; cursor:wait; }
    .center{display:flex; justify-content:center; margin-top:10px}
    .status{margin-left:8px; font-size:.9rem; color:#5f6e6a}
    .ok{color:#1E4D3B} .fail{color:#9b1c1c}
    .pill{display:inline-flex; align-items:center; gap:8px; background:#eaf1ed; color:#1E4D3B; font-weight:700; padding:8px 12px; border-radius:999px}
    .table-wrap{width:100%; overflow-x:auto}
    table{width:100%; border-collapse:collapse; margin-top:12px; background:#fff; border-radius:14px; overflow:hidden; table-layout:auto}
    th,td{border:1px solid #eee; padding:10px; text-align:left; vertical-align:middle; white-space:nowrap}
    th{background:#f6f6f4}
    td input[type="text"], td input[type="email"], td input[type="number"]{width:auto; max-width:280px}
    .actions-col{display:flex; flex-direction:column; align-items:center; gap:8px}
    .tag{display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; font-weight:600}
    .tag.programado{background:#fff3cd; color:#ad7b00}
    .tag.viajando{background:#e7f5ff; color:#0b60a8}
    .tag.finalizado{background:#eaf7ea; color:#1d6b2b}
    .docs{display:flex; flex-direction:column; gap:6px}
    .docs small{color:var(--muted)}
    .doc-list{display:flex; flex-direction:column; gap:4px}
    .doc-item{display:flex; gap:8px; align-items:center}
    .doc-item a{color:#0b60a8; text-decoration:none}
    .doc-item button{padding:4px 8px; border-radius:8px}
    .doc-empty{ color:#7a7a7a; font-style:italic; }
    .doc-tools{ margin-bottom:.4rem; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Viajes vendidos · seguimiento + reseñas</h1>

    <div class="actions-top">
      <button class="btn" id="reload">Cargar servidor</button>
      <button class="btn" id="save">Guardar servidor</button>
      <a class="btn alt" href="/admin/home.php">← Volver al panel</a>
      <span id="st" class="status"></span>
    </div>

    <div class="card">
      <h2>Filtros</h2>
      <div class="grid filters">
        <div class="field">
          <label class="label" for="filter">Por nombre (sin acentos y sin may/min):</label>
          <input id="filter" placeholder="Escribe parte del nombre…" />
        </div>
        <div class="field">
          <label class="label" for="filterState">Por estado del viaje:</label>
          <select id="filterState">
            <option value="">Todos</option>
            <option value="programado">⏳ Programado</option>
            <option value="viajando">✈️ Viajando</option>
            <option value="finalizado">✅ Finalizado</option>
          </select>
        </div>
      </div>
      <div class="center">
        <button class="btn" id="clearFilter">Limpiar filtros</button>
      </div>
    </div>

    <div class="card">
      <h2>Nuevo viaje</h2>
      <div class="grid newtrip">
        <div class="field"><label class="label" for="cliente">Cliente</label><input id="cliente" placeholder="Nombre y apellidos"></div>
        <div class="field"><label class="label" for="email">Email</label><input id="email" placeholder="Email del cliente" type="email"></div>
        <div class="field"><label class="label" for="telefono">Teléfono</label><input id="telefono" placeholder="+34…"></div>
        <div class="field"><label class="label" for="destino">Destino</label><input id="destino" placeholder="Ej. Berlín"></div>
        <div class="field"><label class="label" for="inicio">Inicio</label><input id="inicio" placeholder="YYYY-MM-DD / DDMMAAAA" inputmode="numeric"></div>
        <div class="field"><label class="label" for="noches">Noches</label><input id="noches" placeholder="Noches" type="number" min="1"></div>
      </div>
      <div class="center">
        <button class="btn alt" id="add">Añadir viaje</button>
      </div>
      <div class="center" style="margin-top:8px">
        <span id="pill" class="pill" style="display:none">Vuelve el <span id="pillDate"></span></span>
      </div>
    </div>

    <div class="table-wrap">
      <table id="tbl">
        <thead>
          <tr>
            <th>ID</th>
            <th>Cliente</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Destino</th>
            <th>Inicio</th>
            <th>Noches</th>
            <th>Vuelta</th>
            <th>Estado viaje</th>
            <th>Estado reseña</th>
            <th>Últ. envío</th>
            <th>Documentación</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>
  </div>

  <script>
    // ===== Estado y utilidades =====
    let data={bookings:[]};
    let filterText=''; let filterState='';
    const tbody=document.querySelector('#tbl tbody'); const st=document.getElementById('st');

    function normStr(s){ return (s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase(); }
    function pad(n){ return n<10 ? '0'+n : ''+n; }
    function toISODate(d){ return d.getFullYear() + '-' + pad(d.getMonth()+1) + '-' + pad(d.getDate()); }

    function normalizeDateString(s){
      if(!s) return '';
      s = s.trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s; // YYYY-MM-DD
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)){ const [dd,mm,yyyy] = s.split('/'); return yyyy+'-'+mm+'-'+dd; }
      const digits = s.replace(/\D/g,'');
      if (digits.length===8){
        const dd=digits.slice(0,2), mm=digits.slice(2,4), yyyy=digits.slice(4);
        const yyyy2=digits.slice(0,4), mm2=digits.slice(4,6), dd2=digits.slice(6,8);
        const ddi=parseInt(dd,10), mmi=parseInt(mm,10);
        return (ddi>=1&&ddi<=31&&mmi>=1&&mmi<=12) ? (yyyy+'-'+mm+'-'+dd) : (yyyy2+'-'+mm2+'-'+dd2);
      }
      return s;
    }
    function parseAsDateISO(s){
      const n=normalizeDateString(s);
      if(!/^\d{4}-\d{2}-\d{2}$/.test(n)) return null;
      const d=new Date(n+'T00:00:00'); return isNaN(d.getTime())?null:d;
    }
    function calcVueltaStr(inicioStr, noches){
      const d = parseAsDateISO(inicioStr); const n = parseInt(noches,10);
      if(!d || !Number.isFinite(n) || n<0) return '';
      const ret = new Date(d.getTime()); ret.setDate(ret.getDate()+n);
      return toISODate(ret);
    }
    function travelStatus(start, nights){
      const hoy = new Date(); hoy.setHours(0,0,0,0);
      const dInicio = parseAsDateISO(start);
      const vueltaISO = calcVueltaStr(start, nights);
      const dVuelta = vueltaISO ? new Date(vueltaISO+'T00:00:00') : null;
      if (!dInicio || !dVuelta) return {label:'-', cls:''};
      if (hoy < dInicio) return {label:'⏳ Programado', cls:'programado'};
      if (hoy >= dInicio && hoy <= dVuelta) return {label:'✈️ Viajando', cls:'viajando'};
      return {label:'✅ Finalizado', cls:'finalizado'};
    }
    function reviewLink(token){ return location.origin + '/opiniones/index.php?t=' + token; }
    function rnd(n){const ch='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';let s='';for(let k=0;k<n;k++){s+=ch[Math.floor(Math.random()*ch.length)];}return s;}
    function maxId(){ return data.bookings.reduce((m,b)=>Math.max(m, b.id||0), 0); }

    // ===== Documentos =====
    function docListHTML(b){
      const id = b.id;
      const files = (b.docs||[]);
      const links = files.length
        ? files.map(fn=>{
            const url = `/api/download_doc.php?id=${encodeURIComponent(id)}&f=${encodeURIComponent(fn)}`;
            return `<div class="doc-item">📎 <a href="${url}" target="_blank" rel="noopener">${fn}</a> <button class="btn warn btn-del-doc" data-id="${id}" data-f="${encodeURIComponent(fn)}">Eliminar</button></div>`;
          }).join('')
        : '<div class="doc-empty">Sin archivos</div>';
      const btn = `<div class="doc-tools"><button class="btn-ghost reindex-one" data-reindex-id="${id}" title="Re-vincular docs de este viaje">🔄 Reindexar</button></div>`;
      return `<div class="docs-cell" data-id="${id}">${btn}<div class="doc-list">${links}</div></div>`;
    }

    // ===== Render =====
    function rowHTML(b,i){
      const vuelta = calcVueltaStr(b.start_date, b.nights);
      const tStat = travelStatus(b.start_date, b.nights);
      const reviewState = (b.review_done?'✅ Hecha':'⏳ Pendiente');
      return `
      <tr data-idx="${i}" data-name="${normStr(b.client||'')}" data-state="${tStat.cls}">
        <td>${b.id}</td>
        <td><input data-i="${i}" data-k="client" value="${b.client||''}" /></td>
        <td><input data-i="${i}" data-k="email" type="email" value="${b.email||''}" /></td>
        <td><input data-i="${i}" data-k="phone" value="${b.phone||''}" placeholder="+34…" /></td>
        <td><input data-i="${i}" data-k="destination" value="${b.destination||''}" /></td>
        <td><input data-i="${i}" data-k="start_date" value="${b.start_date||''}" placeholder="YYYY-MM-DD / DDMMAAAA" /></td>
        <td><input data-i="${i}" data-k="nights" type="number" min="0" value="${b.nights||0}" /></td>
        <td class="col-vuelta">${vuelta||'-'}</td>
        <td class="col-status"><span class="tag ${tStat.cls}">${tStat.label}</span></td>
        <td class="col-review">${reviewState}</td>
        <td class="col-last">${b.last_sent||'-'}</td>
        <td class="docs col-docs">
          <input type="file" class="fileup" data-i="${i}" data-id="${b.id}" />
          ${docListHTML(b)}
        </td>
        <td>
          <div class="actions-col">
            <button class="btn send-now" data-send="${i}">Enviar ahora</button>
            <button class="btn warn" data-del="${i}">Borrar</button>
          </div>
        </td>
      </tr>`;
    }

    function render(){
      const f = normStr(filterText||'');
      const s = (filterState||'').trim();
      tbody.innerHTML = data.bookings
        .map((b,i)=>({b,i, html:rowHTML(b,i)}))
        .filter(obj => {
          const nameOk = f==='' || normStr(obj.b.client||'').includes(f);
          const tStat = travelStatus(obj.b.start_date, obj.b.nights);
          const stateOk = s==='' || tStat.cls===s;
          return nameOk && stateOk;
        })
        .map(obj=>obj.html).join('');
    }

    async function loadServer(){
      try{
        const r = await fetch('/api/load_bookings.php'); const j = await r.json();
        data = j && j.bookings ? j : {bookings:[]};
        data.bookings.forEach(b=>{ if(b.start_date){ b.start_date = normalizeDateString(b.start_date); } if(!b.docs) b.docs=[]; });
        render();
        st.textContent='Cargado'; st.className='status ok'; setTimeout(()=>st.textContent='',1500);
      }catch(e){ st.textContent='No se pudo cargar'; st.className='status fail'; }
    }
    async function saveServer(show=true){
      try{
        const body=new FormData(); body.append('payload', JSON.stringify(data));
        const r = await fetch('/api/save_bookings.php',{method:'POST', body});
        const t = await r.text();
        if(t.trim().startsWith('OK')){ if(show){ st.textContent='Guardado'; st.className='status ok'; setTimeout(()=>st.textContent='',1200);} }
        else { if(show){ st.textContent='Error guardando: '+t; st.className='status fail'; } }
      }catch(e){ if(show){ st.textContent='Error de red al guardar'; st.className='status fail'; }
      }
    }
    let tmr=null; function debounceSave(){ if(tmr) clearTimeout(tmr); tmr=setTimeout(()=>saveServer(false), 600); }

    // ===== Pastilla “Vuelve el …” (dinámica) =====
    const elInicio=document.getElementById('inicio');
    const elNoches=document.getElementById('noches');
    const pill=document.getElementById('pill');
    const pillDate=document.getElementById('pillDate');
    function pad2(x){ return x<10?'0'+x:x; }
    function updatePill(){
      const norm = normalizeDateString(elInicio.value);
      if (norm !== elInicio.value){ elInicio.value = norm; }
      const retISO = calcVueltaStr(norm, elNoches.value||0);
      if (retISO){
        const d = new Date(retISO + 'T00:00:00');
        pillDate.textContent = pad2(d.getDate()) + '/' + pad2(d.getMonth()+1) + '/' + d.getFullYear();
        pill.style.display='inline-flex';
      } else { pill.style.display='none'; }
    }
    ['input','blur'].forEach(ev=>{
      elInicio.addEventListener(ev, updatePill);
      elNoches.addEventListener(ev, updatePill);
    });

    // ===== Añadir viaje =====
    document.getElementById('add').onclick=()=>{
      const c=document.getElementById('cliente').value.trim();
      const em=document.getElementById('email').value.trim();
      const ph=document.getElementById('telefono').value.trim();
      const d=document.getElementById('destino').value.trim();
      let i=document.getElementById('inicio').value.trim();
      const n=parseInt(document.getElementById('noches').value||'0',10);
      if(!c||!em||!d||!i||!n){ alert('Rellena todos los campos'); return; }
      i = normalizeDateString(i);
      const id=maxId()+1; const token=rnd(24);
      data.bookings.push({id, client:c, email:em, phone:ph, destination:d, start_date:i, nights:n, token, review_done:false, sent_count:0, last_sent:'', docs:[]});
      render(); saveServer();
      ['cliente','email','telefono','destino','inicio','noches'].forEach(x=>document.getElementById(x).value=''); pill.style.display='none';
    };

    // ===== INPUT en línea (sin perder foco, sin re-render total) =====
    tbody.addEventListener('input', (e)=>{
      const t=e.target; const i=t.getAttribute('data-i'); const k=t.getAttribute('data-k');
      if(i==null||!k) return;
      let val = t.value;
      if (k==='start_date'){ val = normalizeDateString(val); }
      if (k==='nights'){ val = parseInt(val||'0',10) || 0; }
      data.bookings[parseInt(i)][k] = val;

      // Actualiza solo columnas dependientes de la fila
      const tr = t.closest('tr');
      if (tr){
        const b = data.bookings[parseInt(i)];
        // Vuelta
        const vueltaISO = calcVueltaStr(b.start_date, b.nights);
        const colVuelta = tr.querySelector('.col-vuelta');
        if (colVuelta) colVuelta.textContent = vueltaISO || '-';
        // Estado viaje
        const st = travelStatus(b.start_date, b.nights);
        const colStatus = tr.querySelector('.col-status');
        if (colStatus) colStatus.innerHTML = `<span class="tag ${st.cls}">${st.label}</span>`;
      }
      debounceSave();
    });

    // ===== Acciones por fila =====
    tbody.addEventListener('change', async e=>{
      if(e.target.matches('.fileup')){
        const i = parseInt(e.target.getAttribute('data-i'),10);
        const id = parseInt(e.target.getAttribute('data-id'),10);
        const f = e.target.files[0]; if(!f){ return; }
        const fm = new FormData(); fm.append('id', id); fm.append('file', f);
        const r = await fetch('/api/upload_doc.php', {method:'POST', body:fm, credentials:'include'});
        const t = await r.json().catch(()=>null);
        if(t && t.ok){
          if(!data.bookings[i].docs) data.bookings[i].docs=[];
          data.bookings[i].docs.push(t.name);
          // Actualiza solo la celda de docs
          const tr = e.target.closest('tr');
          const cell = tr ? tr.querySelector('.col-docs') : null;
          if (cell) cell.innerHTML = `<input type="file" class="fileup" data-i="${i}" data-id="${id}" />` + docListHTML(data.bookings[i]);
          saveServer(false);
        } else {
          alert('Error subiendo documento');
        }
        e.target.value='';
      }
    });

    tbody.addEventListener('click', async e=>{
      // Enviar ahora (no re-render global)
      if(e.target.matches('.send-now')){
        const idx=parseInt(e.target.getAttribute('data-send'),10);
        const b=data.bookings[idx];
        const btn=e.target; btn.disabled=true; btn.textContent='Enviando…';

        const body=new FormData();
        body.append('to', b.email);
        body.append('link', reviewLink(b.token));
        body.append('name', b.client||'');
        body.append('destination', (b.destination||''));

        const r = await fetch('/api/send_token.php', {method:'POST', body, credentials:'include'});
        const t = await r.text();
        if(t.trim().startsWith('OK')){
          b.last_sent = toISODate(new Date());
          b.sent_count = (b.sent_count||0)+1;
          // actualiza solo la celda de último envío
          const tr = btn.closest('tr'); const last = tr ? tr.querySelector('.col-last') : null;
          if (last) last.textContent = b.last_sent;
          saveServer(false);
          btn.textContent='Enviado 📧';
        } else {
          btn.textContent='⚠️ Error'; console.log('send error:', t);
        }
        setTimeout(()=>{ btn.disabled=false; btn.textContent='Enviar ahora'; }, 1800);
        return;
      }

      // Borrar fila (sí re-render)
      const di=e.target.getAttribute('data-del');
      if(di!=null){ data.bookings.splice(parseInt(di,10),1); render(); saveServer(); return; }

      // Borrar doc (sin re-render global)
      if(e.target.matches('.btn-del-doc')){
        const id = e.target.getAttribute('data-id');
        const fname = e.target.getAttribute('data-f');
        if(!confirm('¿Eliminar este documento?')) return;
        const fm = new FormData(); fm.append('id', id); fm.append('f', fname);
        const r = await fetch('/api/delete_doc.php', {method:'POST', body:fm, credentials:'include'});
        const t = await r.json().catch(()=>null);
        if(t && t.ok){
          // quita del array
          const tr = e.target.closest('tr');
          const i = parseInt(tr.getAttribute('data-idx'),10);
          if (!isNaN(i)) {
            const arr = data.bookings[i].docs||[];
            data.bookings[i].docs = arr.filter(n => n !== decodeURIComponent(fname));
            // refresca solo docs cell
            const cell = tr.querySelector('.col-docs');
            if (cell) cell.innerHTML = `<input type="file" class="fileup" data-i="${i}" data-id="${id}" />` + docListHTML(data.bookings[i]);
            saveServer(false);
          }
        } else {
          alert('No se pudo eliminar');
        }
      }

      // Reindexar solo esta fila (ID)
      const rb = e.target.closest('.reindex-one');
      if(rb){
        const id = parseInt(rb.getAttribute('data-reindex-id'),10);
        rb.disabled=true; const prev=rb.textContent; rb.textContent='🔄 Reindexando...';
        try{
          const r = await fetch('/api/rebuild_docs.php?id='+id, {credentials:'include'});
          const j = await r.json();
          if(j && j.ok){
            // actualiza docs del booking en memoria
            const idx = data.bookings.findIndex(b => parseInt(b.id,10)===id);
            if (idx>=0){ data.bookings[idx].docs = j.docs || []; }
            // refresca solo la celda
            const tr = rb.closest('tr');
            const cell = tr ? tr.querySelector('.col-docs') : null;
            if (cell) cell.innerHTML = `<input type="file" class="fileup" data-i="${idx}" data-id="${id}" />` + docListHTML(data.bookings[idx]);
            rb.textContent='✅ Hecho';
          } else {
            rb.textContent='⚠️ Error';
          }
        }catch(err){ rb.textContent='⚠️ Error'; }
        finally{ setTimeout(()=>{ rb.textContent=prev; rb.disabled=false; }, 1500); }
      }
    });

    // ===== Filtros =====
    const filterEl=document.getElementById('filter');
    const filterStateEl=document.getElementById('filterState');
    const clearFilter=document.getElementById('clearFilter');
    filterEl.addEventListener('input', ()=>{ filterText = filterEl.value; render(); });
    filterStateEl.addEventListener('change', ()=>{ filterState = filterStateEl.value; render(); });
    clearFilter.addEventListener('click', ()=>{ filterText=''; filterState=''; filterEl.value=''; filterStateEl.value=''; render(); });

    // ===== Botones top =====
    document.getElementById('reload').onclick=()=>loadServer();
    document.getElementById('save').onclick=()=>saveServer();

    // ===== Init =====
    loadServer();
  </script>
</body>
</html>
