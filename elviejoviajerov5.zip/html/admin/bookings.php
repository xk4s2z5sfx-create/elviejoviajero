<?php
// Wrapper bookings.php -> añade confirmación al borrar sin tocar tu archivo original.
// PASOS: renombra tu bookings actual a bookings_inner.php y sube este archivo como bookings.php.
ob_start();
$inner = __DIR__ . '/bookings_inner.php';
if (file_exists($inner)) {
  require $inner;
} else {
  echo "<!doctype html><meta charset='utf-8'><body style='font-family:system-ui'>";
  echo "<h2>Falta bookings_inner.php</h2><p>Renombra tu bookings original a <code>bookings_inner.php</code>.</p>";
}
$html = ob_get_clean();

$script = <<<HTML
<script>
(function(){
  function summarize(row){
    try{
      const val = sel => row && row.querySelector(sel);
      const v   = el => el ? (el.value || el.textContent || '').trim() : '';
      const client = v(val('[data-k="client"], .client'));
      const dest   = v(val('[data-k="destination"], .destination'));
      const start  = v(val('[data-k="start_date"], .start_date'));
      const nights = v(val('[data-k="nights"], .nights'));
      return (client||'—') + ' · ' + (dest||'—') + ' · ' + (start||'') + (nights?(' ('+nights+' noches)'):''); 
    }catch(e){ return ''; }
  }

  document.addEventListener('click', function(e){
    const delBtn = e.target.closest('[data-del], .del-btn');
    if(!delBtn) return;
    const row = delBtn.closest('tr');
    const resume = summarize(row);
    const msg = "¿Seguro que quieres borrar este viaje?\\n\\n" + resume + "\\n\\nEsta acción no se puede deshacer.";
    if(!confirm(msg)){
      e.preventDefault();
      e.stopPropagation();
      return false;
    }
  }, true);
})();
</script>
HTML;

if (stripos($html, '</body>') !== false) {
  $html = str_ireplace('</body>', $script . '</body>', $html);
} else {
  $html .= $script;
}
echo $html;
