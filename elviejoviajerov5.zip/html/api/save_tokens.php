
<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo "ERROR: method not allowed"; exit; }
$payload = $_POST['payload'] ?? '';
if ($payload === '') { http_response_code(400); echo "ERROR: missing payload"; exit; }
$data = json_decode($payload, true);
if (!is_array($data) || !isset($data['tokens']) || !is_array($data['tokens'])) { http_response_code(400); echo "ERROR: invalid JSON"; exit; }
$dir = dirname(__DIR__) . '/data';
$file = $dir . '/review_tokens.json';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
$fp = fopen($file, 'c+'); if(!$fp){ http_response_code(500); echo "ERROR: open file"; exit; }
flock($fp, LOCK_EX); ftruncate($fp, 0);
fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
fflush($fp); flock($fp, LOCK_UN); fclose($fp);
echo "OK";
