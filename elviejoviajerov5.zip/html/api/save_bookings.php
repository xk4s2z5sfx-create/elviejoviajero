<?php
// /api/save_bookings.php
header('Content-Type: text/plain; charset=UTF-8');

$dir  = dirname(__DIR__) . '/data';
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
$file = $dir . '/bookings.json';

$payload = '';
if (isset($_POST['payload'])) {
  $payload = $_POST['payload'];
} else {
  $payload = file_get_contents('php://input');
}

if ($payload === '' || $payload === null) { http_response_code(400); echo "ERROR: empty payload"; exit; }

$data = json_decode($payload, true);
if (!$data || !isset($data['bookings']) || !is_array($data['bookings'])) { http_response_code(400); echo "ERROR: bad json"; exit; }

// Validación ligera y whitelist de campos
$clean = [];
foreach ($data['bookings'] as $b) {
  $clean[] = [
    'id'          => isset($b['id']) ? intval($b['id']) : 0,
    'client'      => isset($b['client']) ? (string)$b['client'] : '',
    'email'       => isset($b['email']) ? (string)$b['email'] : '',
    'phone'       => isset($b['phone']) ? (string)$b['phone'] : '',
    'destination' => isset($b['destination']) ? (string)$b['destination'] : '',
    'start_date'  => isset($b['start_date']) ? (string)$b['start_date'] : '',
    'nights'      => isset($b['nights']) ? intval($b['nights']) : 0,
    'token'       => isset($b['token']) ? (string)$b['token'] : '',
    'review_done' => !empty($b['review_done']) ? true : false,
    'sent_count'  => isset($b['sent_count']) ? intval($b['sent_count']) : 0,
    'last_sent'   => isset($b['last_sent']) ? (string)$b['last_sent'] : '',
  ];
}

$out = ['bookings' => $clean];
$tmp = $file . '.tmp';
if (file_put_contents($tmp, json_encode($out, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)) === false) {
  http_response_code(500); echo "ERROR: write tmp failed"; exit;
}
if (!@rename($tmp, $file)) { http_response_code(500); echo "ERROR: rename failed"; exit; }

echo "OK";
