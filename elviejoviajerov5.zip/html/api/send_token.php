<?php
// /api/send_token.php
session_start();
header('Content-Type: text/plain; charset=UTF-8');

if (empty($_SESSION['evv_admin'])) {
  http_response_code(401);
  echo "ERROR: unauthorized";
  exit;
}

$to    = trim($_POST['to'] ?? '');
$link  = trim($_POST['link'] ?? '');
$name  = trim($_POST['name'] ?? '');
$dest  = trim($_POST['destination'] ?? '');

if ($to === '' || $link === '') {
  http_response_code(400);
  echo "ERROR: missing fields";
  exit;
}
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
  http_response_code(400);
  echo "ERROR: invalid email";
  exit;
}

// Plantilla unificada (igual que cron)
$subject = '¿Nos dejas tu reseña? ✍️ El Viejo Viajero';

$nombreSeguro  = $name !== '' ? '<strong>'.htmlspecialchars($name).'</strong>' : '';
$destinoSeguro = $dest !== '' ? '<strong>'.htmlspecialchars($dest).'</strong>' : '';

$bodyHtml  = '<p>¡Hola'.($nombreSeguro ? ' '.$nombreSeguro : '').'!</p>';
$bodyHtml .= '<p>Espero que tu viaje a '.($destinoSeguro ? $destinoSeguro : '<strong>tu destino</strong>').' fuera genial. ';
$bodyHtml .= 'Nos ayudarías mucho dejando tu reseña:</p>';
$bodyHtml .= '<p><a href="'.htmlspecialchars($link).'" style="display:inline-block;background:#1E4D3B;color:#fff;padding:12px 18px;border-radius:10px;text-decoration:none;font-size:16px;">💬 Escribir reseña</a></p>';
$bodyHtml .= '<p>Si por algún motivo tu experiencia no fue la esperada, puedes escribirnos a ';
$bodyHtml .= '<a href="mailto:hola@elviejoviajero.es">hola@elviejoviajero.es</a> ';
$bodyHtml .= 'o contactarnos por <a href="https://wa.me/34614451169" target="_blank">WhatsApp</a>. ';
$bodyHtml .= 'Nos encantará conocer tu opinión para seguir mejorando cada día.</p>';
$bodyHtml .= '<p>Gracias por confiar en <strong>El Viejo Viajero</strong> 🙌<br>';
$bodyHtml .= 'Estaremos encantados de acompañarte en tu próxima aventura ✈️</p>';
$bodyHtml .= '<p>Un saludo,<br><strong>El equipo de El Viejo Viajero</strong> 🕵🏽‍♂️</p>';

$bodyText  = '¡Hola'.($name!=='' ? ' '.$name : '')."!\\n\\n";
$bodyText .= 'Espero que tu viaje a '.($dest!=='' ? $dest : 'tu destino').' fuera genial. ';
$bodyText .= "Nos ayudarías mucho dejando tu reseña:\\n{$link}\\n\\n";
$bodyText .= "Si por algún motivo tu experiencia no fue la esperada, puedes escribirnos a hola@elviejoviajero.es ";
$bodyText .= "o contactarnos por WhatsApp (+34 614 451 169). Nos encantará conocer tu opinión para seguir mejorando.\\n\\n";
$bodyText .= "Gracias por confiar en El Viejo Viajero 🙌\\n";
$bodyText .= "Estaremos encantados de acompañarte en tu próxima aventura ✈️\\n\\n";
$bodyText .= "Un saludo,\\nEl equipo de El Viejo Viajero 🕵🏽‍♂️";

// Enviar con mailer SMTP si existe
$mailerPath = __DIR__ . '/mailer.php';
if (!file_exists($mailerPath)) {
  http_response_code(500);
  echo "ERROR: mailer.php not found (SMTP not configured)";
  exit;
}
require_once $mailerPath;
if (!function_exists('send_mail_html')) {
  http_response_code(500);
  echo "ERROR: send_mail_html() not available in mailer.php";
  exit;
}

try {
  $ok = send_mail_html($to, $subject, $bodyHtml, $bodyText);
  if ($ok) { echo "OK"; }
  else { http_response_code(500); echo "ERROR: SMTP send returned false"; }
} catch (Throwable $e) {
  http_response_code(500);
  echo "ERROR: SMTP exception: " . $e->getMessage();
}
