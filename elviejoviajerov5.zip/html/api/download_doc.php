<?php
session_start();
if (empty($_SESSION['evv_admin'])) { http_response_code(401); echo "Unauthorized"; exit; }
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$f  = isset($_GET['f']) ? (string)$_GET['f'] : '';
if ($id<=0 || $f==='') { http_response_code(400); echo "Bad request"; exit; }
$ROOT = dirname(__DIR__);
$path = $ROOT . '/data/docs/' . $id . '/' . basename($f);
if (!is_file($path)) { http_response_code(404); echo "Not found"; exit; }
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$ctype = 'application/octet-stream';
if ($ext==='pdf') $ctype='application/pdf';
if ($ext==='png') $ctype='image/png';
if ($ext==='jpg' || $ext==='jpeg') $ctype='image/jpeg';
if ($ext==='webp') $ctype='image/webp';
header('Content-Type: '.$ctype);
header('Content-Disposition: inline; filename="'.basename($path).'"');
readfile($path);
