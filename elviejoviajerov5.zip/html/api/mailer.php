<?php
/**
 * api/mailer.php (SMTP version)
 * Envío por SMTP autenticado (STARTTLS 587) para IONOS.
 * - Remitente: El Viejo Viajero <noreply@elviejoviajero.es>
 * - Reply-To: hola@elviejoviajero.es
 * - Adjuntos soportados (multipart/mixed)
 * Si SMTP falla, intenta fallback con mail() nativo.
 *
 * Configura tus credenciales aquí:
 */
define('EVV_SMTP_HOST', 'smtp.ionos.es');
define('EVV_SMTP_PORT', 587);
define('EVV_SMTP_USER', 'noreply@elviejoviajero.es');
define('EVV_SMTP_PASS', 'a47427798G.');
define('EVV_FROM_NAME', 'El Viejo Viajero');
define('EVV_FROM_ADDR', 'noreply@elviejoviajero.es');
define('EVV_REPLY_TO',  'hola@elviejoviajero.es');

/** Utilidad: encoded-word UTF-8 */
function evv_enc($s){ return '=?UTF-8?B?'.base64_encode($s).'?='; }

/** SMTP client simple con STARTTLS y AUTH LOGIN */
class EVV_Smtp {
  private $fp = null;
  private $debug = false;
  public function __construct($debug=false){ $this->debug = $debug; }
  private function put($line){
    if($this->debug){ error_log(">> ".$line); }
    return fwrite($this->fp, $line."\r\n");
  }
  private function get(){
    $resp='';
    while(!feof($this->fp)){
      $l = fgets($this->fp, 515);
      if($l===false) break;
      $resp .= $l;
      if($this->debug){ error_log("<< ".$l); }
      if(strlen($l)>=4 && $l[3]==' ') break;
    }
    return $resp;
  }
  private function expect($code, $resp){
    if(substr($resp,0,3)!==strval($code)) throw new Exception("SMTP expected {$code}, got: ".trim($resp));
  }
  public function sendMessage($from, $to, $raw){
    $ctx = stream_context_create(['ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
    $this->fp = stream_socket_client(EVV_SMTP_HOST.':'.EVV_SMTP_PORT, $errno, $errstr, 20, STREAM_CLIENT_CONNECT, $ctx);
    if(!$this->fp) throw new Exception("connect fail: $errstr ($errno)");
    stream_set_timeout($this->fp, 20);
    $this->expect(220, $this->get());
    $this->put('EHLO elviejoviajero.es'); $this->expect(250, $this->get());
    $this->put('STARTTLS'); $this->expect(220, $this->get());
    if(!stream_socket_enable_crypto($this->fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)){
      throw new Exception("tls fail");
    }
    $this->put('EHLO elviejoviajero.es'); $this->expect(250, $this->get());
    $this->put('AUTH LOGIN'); $this->expect(334, $this->get());
    $this->put(base64_encode(EVV_SMTP_USER)); $this->expect(334, $this->get());
    $this->put(base64_encode(EVV_SMTP_PASS)); $this->expect(235, $this->get());
    $this->put('MAIL FROM:<'.$from.'>'); $this->expect(250, $this->get());
    foreach($to as $rcpt){
      $this->put('RCPT TO:<'.$rcpt.'>'); $this->expect(250, $this->get());
    }
    $this->put('DATA'); $this->expect(354, $this->get());
    // Asegura CRLF y dot-stuffing
    $safe = preg_replace("/\r?\n/", "\r\n", $raw);
    $safe = str_replace("\r\n.", "\r\n..", $safe);
    $this->put($safe."\r\n.");
    $this->expect(250, $this->get());
    $this->put('QUIT'); $this->get();
    fclose($this->fp); $this->fp=null;
    return true;
  }
}

/** Construcción de mensaje MIME (HTML + Alt + adjuntos) */
class EVV_Mime {
  public $subject=''; public $html=''; public $alt=''; public $to=[];
  public $fromName=EVV_FROM_NAME; public $fromAddr=EVV_FROM_ADDR; public $replyTo=EVV_REPLY_TO;
  private $atts=[];
  public function addAddress($email){ $this->to[] = $email; }
  public function addAttachment($path, $name=''){ if(is_file($path)) $this->atts[] = [$path, $name?:basename($path)]; }
  public function build(){
    $bMain = "=_EVV_".md5(uniqid('',true));
    $bAlt  = "=_EVV_ALT_".md5(uniqid('',true));
    $encFrom = evv_enc($this->fromName).' <'.$this->fromAddr.'>';
    $hdr  = "From: ".$encFrom."\r\n";
    $hdr .= "Reply-To: ".$this->replyTo."\r\n";
    $hdr .= "MIME-Version: 1.0\r\n";
    $hdr .= "Date: ".date('r')."\r\n";
    $hdr .= "Message-ID: <".uniqid()."@elviejoviajero.es>\r\n";
    if(empty($this->atts)){
      $hdr .= "Content-Type: multipart/alternative; boundary=\"$bAlt\"\r\n";
      $alt  = "--$bAlt\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".($this->alt!==''?$this->alt:strip_tags($this->html))."\r\n\r\n";
      $alt .= "--$bAlt\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$this->html."\r\n\r\n--$bAlt--\r\n";
      $raw = "Subject: ".evv_enc($this->subject)."\r\n".$hdr."\r\n".$alt;
      return $raw;
    } else {
      $hdr .= "Content-Type: multipart/mixed; boundary=\"$bMain\"\r\n";
      $alt  = "--$bMain\r\nContent-Type: multipart/alternative; boundary=\"$bAlt\"\r\n\r\n";
      $alt .= "--$bAlt\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".($this->alt!==''?$this->alt:strip_tags($this->html))."\r\n\r\n";
      $alt .= "--$bAlt\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n".$this->html."\r\n\r\n--$bAlt--\r\n";
      $raw  = "Subject: ".evv_enc($this->subject)."\r\n".$hdr."\r\n".$alt;
      foreach($this->atts as [$p,$n]){
        $mime = function_exists('mime_content_type') ? mime_content_type($p) : 'application/octet-stream';
        $data = chunk_split(base64_encode(file_get_contents($p)));
        $safe = preg_replace('/[^A-Za-z0-9._ -]+/', '_', $n);
        $raw .= "--$bMain\r\nContent-Type: $mime; name=\"$safe\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=\"$safe\"\r\n\r\n".$data."\r\n";
      }
      $raw .= "--$bMain--\r\n";
      return $raw;
    }
  }
}

/** API pública compatible con el resto del proyecto */
class EVV_SmtpMailer {
  public $Subject=''; public $AltBody=''; private $html=''; private $to=[]; private $atts=[];
  public function addAddress($email,$name=''){ $this->to[]=$email; }
  public function setFrom($email,$name=''){ /* From fijo en config */ }
  public function setReplyTo($email){ /* Reply-To fijo en config */ }
  public function msgHTML($html){ $this->html=$html; }
  public function addAttachment($path,$name=''){ if(is_file($path)) $this->atts[] = [$path, $name?:basename($path)]; }
  public function send(){
    if(empty($this->to)) return false;
    $mime = new EVV_Mime();
    $mime->subject = $this->Subject;
    $mime->html    = $this->html;
    $mime->alt     = $this->AltBody;
    foreach($this->atts as $a) $mime->addAttachment($a[0], $a[1]);
    $raw = $mime->build();
    try {
      $smtp = new EVV_Smtp(false);
      $smtp->sendMessage(EVV_FROM_ADDR, $this->to, $raw);
      return true;
    } catch(Exception $e){
      // Fallback a mail() si SMTP falla
      $headers  = "MIME-Version: 1.0\r\n";
      $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
      $headers .= "From: ".evv_enc(EVV_FROM_NAME)." <".EVV_FROM_ADDR.">\r\n";
      $headers .= "Reply-To: ".EVV_REPLY_TO."\r\n";
      return @mail($this->to[0], evv_enc($this->Subject), $this->html, $headers, "-f ".EVV_FROM_ADDR);
    }
  }
}

/** Compat: usada por partes antiguas sin adjuntos */
function send_mail_html($to, $subject, $html, $text=''){
  $m = new EVV_Mime();
  $m->subject = $subject; $m->html = $html; $m->alt = $text;
  $raw = $m->build();
  try {
    $smtp = new EVV_Smtp(false);
    $smtp->sendMessage(EVV_FROM_ADDR, [$to], $raw);
    return true;
  } catch(Exception $e){
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: ".evv_enc(EVV_FROM_NAME)." <".EVV_FROM_ADDR.">\r\n";
    $headers .= "Reply-To: ".EVV_REPLY_TO."\r\n";
    return @mail($to, evv_enc($subject), $html, $headers, "-f ".EVV_FROM_ADDR);
  }
}

/** Punto de entrada actual para el cron y envíos con adjuntos */
function get_mailer(){ return new EVV_SmtpMailer(); }
