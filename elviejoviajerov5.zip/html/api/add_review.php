
<?php
date_default_timezone_set('Europe/Madrid');
$author = trim($_POST['author'] ?? '');
$text = trim($_POST['text'] ?? '');
$token = trim($_POST['token'] ?? '');
$website = trim($_POST['website'] ?? '');
if ($website !== '') { echo "ERROR: spam"; exit; }
if ($author === '' || $text === '' || $token === '') { echo "ERROR: missing fields"; exit; }
$base = dirname(__DIR__);
$tokensFile = $base . '/data/review_tokens.json';
$reviewsFile = $base . '/data/reviews.json';
$bookingsFile = $base . '/data/bookings.json';
$tokens = ['tokens'=>[]];
if (file_exists($tokensFile)) {
  $j = json_decode(file_get_contents($tokensFile), true);
  if ($j) $tokens = $j;
}
$valid = false; $one = false; $idx = -1;
foreach ($tokens['tokens'] as $k=>$t) {
  if (isset($t['token']) && hash_equals($t['token'], $token)) { $valid=true; $one = !empty($t['one']); $idx=$k; break; }
}
if (!$valid) { echo "ERROR: invalid token"; exit; }
$reviews = ['reviews'=>[]];
if (file_exists($reviewsFile)) { $jr = json_decode(file_get_contents($reviewsFile), true); if ($jr) $reviews = $jr; }
$reviews['reviews'][] = ['author'=>$author,'text'=>$text,'date'=>date('Y-m-d'),'pending'=>true];
file_put_contents($reviewsFile, json_encode($reviews, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
if ($one && $idx>=0) {
  array_splice($tokens['tokens'], $idx, 1);
  file_put_contents($tokensFile, json_encode($tokens, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}
if (file_exists($bookingsFile)) {
  $bk = json_decode(file_get_contents($bookingsFile), true);
  if ($bk && isset($bk['bookings'])) {
    $changed=false;
    foreach ($bk['bookings'] as &$b) {
      if (!empty($b['token']) && hash_equals($b['token'], $token)) { $b['review_done']=true; $changed=true; }
    }
    if ($changed) { file_put_contents($bookingsFile, json_encode($bk, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); }
  }
}
echo "OK";
