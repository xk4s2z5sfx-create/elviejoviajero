
<?php
// api/admin_secrets.php
// ⚠️ EDITA estos valores tras subirlos al servidor.
// Para generar un hash nuevo desde PHP: password_hash('TuNuevaClave', PASSWORD_BCRYPT);
$ADMIN_USER = 'alejandro.cortes';
$ADMIN_PASS_BCRYPT = '$2y$12$Lot1jra2tXK6q8/OGDQc2uumN2yk0XGxcCnSkFu2IYM1IPUILoRbu';
