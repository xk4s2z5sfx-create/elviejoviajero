<?php
// /api/load_bookings.php
header('Content-Type: application/json; charset=UTF-8');

$dir  = dirname(__DIR__) . '/data';
$file = $dir . '/bookings.json';

if (!file_exists($file)) {
  echo json_encode(['bookings'=>[]], JSON_UNESCAPED_UNICODE);
  exit;
}

$raw = file_get_contents($file);
$data = json_decode($raw, true);
if (!$data || !isset($data['bookings']) || !is_array($data['bookings'])) {
  echo json_encode(['bookings'=>[]], JSON_UNESCAPED_UNICODE);
  exit;
}

// Asegurar claves por compatibilidad hacia atrás
foreach ($data['bookings'] as &$b) {
  if (!isset($b['phone']))        $b['phone'] = '';
  if (!isset($b['destination']))  $b['destination'] = '';
  if (!isset($b['review_done']))  $b['review_done'] = false;
  if (!isset($b['sent_count']))   $b['sent_count'] = 0;
  if (!isset($b['last_sent']))    $b['last_sent'] = '';
  if (!isset($b['token']))        $b['token'] = '';
  if (!isset($b['id']))           $b['id'] = 0;
  if (!isset($b['nights']))       $b['nights'] = 0;
  if (!isset($b['start_date']))   $b['start_date'] = '';
  if (!isset($b['client']))       $b['client'] = '';
  if (!isset($b['email']))        $b['email'] = '';
}

echo json_encode(['bookings'=>$data['bookings']], JSON_UNESCAPED_UNICODE);
