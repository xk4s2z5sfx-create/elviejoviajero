<?php
session_start();
/**
 * Reindexa documentos en /data/docs.
 * - GET sin parámetros: reindexa todos los IDs (respuesta en texto)
 * - GET ?id=123       : reindexa solo ese ID y devuelve JSON con la lista de docs
 * Requiere sesión admin (login previo en /admin/).
 */
if (empty($_SESSION['evv_admin'])) {
  http_response_code(401);
  header('Content-Type: text/plain; charset=UTF-8');
  echo "Unauthorized";
  exit;
}

$baseDir  = dirname(__DIR__) . '/data';
$fileJson = $baseDir . '/bookings.json';
$docsBase = $baseDir . '/docs';

// Carga JSON existente
$data = ['bookings'=>[]];
if (file_exists($fileJson)) {
  $tmp = json_decode(file_get_contents($fileJson), true);
  if (is_array($tmp) && isset($tmp['bookings'])) $data = $tmp;
}

// Index por ID
$byId = [];
foreach ($data['bookings'] as $k=>$b) { $byId[intval($b['id']??0)] = $k; }

$oneId = isset($_GET['id']) ? intval($_GET['id']) : 0;

function list_files($dir) {
  $out = [];
  if (!is_dir($dir)) return $out;
  $items = @scandir($dir) ?: [];
  foreach ($items as $it) {
    if ($it==='.' || $it==='..') continue;
    $p = $dir . '/' . $it;
    if (is_file($p)) $out[] = $it;
  }
  sort($out);
  return $out;
}

$added = 0;

if ($oneId > 0) {
  $dir = $docsBase . '/' . $oneId;
  $files = list_files($dir);
  if (isset($byId[$oneId])) {
    $idx = $byId[$oneId];
    if (empty($data['bookings'][$idx]['docs']) || !is_array($data['bookings'][$idx]['docs'])) $data['bookings'][$idx]['docs'] = [];
    foreach ($files as $fn) {
      if (!in_array($fn, $data['bookings'][$idx]['docs'], true)) {
        $data['bookings'][$idx]['docs'][] = $fn; $added++;
      }
    }
  } else {
    // crea booking mínimo si no existe
    $data['bookings'][] = ['id'=>$oneId, 'docs'=>$files];
    $added += count($files);
  }

  // Guardar JSON
  file_put_contents($fileJson, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX);

  // Respuesta JSON solo para ese ID
  header('Content-Type: application/json; charset=UTF-8');
  $docs = [];
  if (isset($byId[$oneId])) {
    $docs = $data['bookings'][$byId[$oneId]]['docs'] ?? [];
  } else {
    // recién creado
    foreach ($data['bookings'] as $b) {
      if (intval($b['id']??0) === $oneId) { $docs = $b['docs'] ?? []; break; }
    }
  }
  echo json_encode(['ok'=>true,'id'=>$oneId,'docs'=>$docs,'added'=>$added]);
  exit;
}

// -------- modo global (sin id) --------
$dirs = @scandir($docsBase) ?: [];
foreach ($dirs as $dir) {
  if ($dir=='.' || $dir=='..') continue;
  $id = intval($dir);
  if ($id <= 0) continue;
  $full = $docsBase . '/' . $dir;
  if (!is_dir($full)) continue;
  $files = list_files($full);
  if (isset($byId[$id])) {
    $idx = $byId[$id];
    if (empty($data['bookings'][$idx]['docs']) || !is_array($data['bookings'][$idx]['docs'])) $data['bookings'][$idx]['docs'] = [];
    foreach ($files as $fn) {
      if (!in_array($fn, $data['bookings'][$idx]['docs'], true)) {
        $data['bookings'][$idx]['docs'][] = $fn; $added++;
      }
    }
  } else {
    $data['bookings'][] = ['id'=>$id, 'docs'=>$files];
    $added += count($files);
  }
}

file_put_contents($fileJson, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT), LOCK_EX);

header('Content-Type: text/plain; charset=UTF-8');
echo "Reindex global OK. Files linked: $added\n";
?>