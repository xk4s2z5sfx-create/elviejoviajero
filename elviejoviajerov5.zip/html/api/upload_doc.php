<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');
if (empty($_SESSION['evv_admin'])) { http_response_code(401); echo json_encode(['ok'=>false,'err'=>'unauthorized']); exit; }
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
if ($id<=0 || empty($_FILES['file'])) { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'bad request']); exit; }
$allowed = ['pdf','png','jpg','jpeg','webp'];
$name = $_FILES['file']['name'] ?? 'file';
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if (!in_array($ext, $allowed)) { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'ext']); exit; }
$ROOT = dirname(__DIR__);
$dir = $ROOT . '/data/docs/' . $id;
if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
$baseName = preg_replace('/[^a-zA-Z0-9._-]+/','_', $name);
$target = $dir . '/' . $baseName;
$k=1;
while (file_exists($target)) {
  $base = pathinfo($baseName, PATHINFO_FILENAME);
  $target = $dir . '/' . $base . '_' . $k . '.' . $ext;
  $k++;
}
if (!move_uploaded_file($_FILES['file']['tmp_name'], $target)) { http_response_code(500); echo json_encode(['ok'=>false,'err'=>'move']); exit; }
echo json_encode(['ok'=>true,'name'=>basename($target)]);
