<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');
if (empty($_SESSION['evv_admin'])) { http_response_code(401); echo json_encode(['ok'=>false,'err'=>'unauthorized']); exit; }
$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$f  = isset($_POST['f']) ? (string)$_POST['f'] : '';
if ($id<=0 || $f==='') { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'bad request']); exit; }
$ROOT = dirname(__DIR__);
$path = $ROOT . '/data/docs/' . $id . '/' . basename(urldecode($f));
if (!is_file($path)) { http_response_code(404); echo json_encode(['ok'=>false,'err'=>'notfound']); exit; }
@unlink($path);
echo json_encode(['ok'=>true]);
