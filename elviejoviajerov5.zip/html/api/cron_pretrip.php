<?php
/**
 * cron_pretrip.php — Recordatorios de viaje (v3 con DEBUG enriquecido)
 * - 7 días (cliente, sin adjuntos)
 * - 48 h (interno, sin adjuntos)
 * - 24 h (cliente, adjunta data/docs/{ID}/* si usa PHPMailer get_mailer())
 *
 * DEBUG: añade &debug=1 para ver rutas detectadas, modo mailer y ficheros adjuntados.
 */
date_default_timezone_set('Europe/Madrid');

/* ===== Seguridad ===== */
$CRON_SECRET = 'UEpdWBph5eRZ6o';
if (!isset($_GET['secret']) || $_GET['secret'] !== $CRON_SECRET) {
  http_response_code(401); echo "Unauthorized"; exit;
}
$DEBUG = isset($_GET['debug']);
function dbg($msg){ if (!empty($GLOBALS['DEBUG'])) echo $msg . "\n"; }

/* ===== Descubrir rutas ===== */
$ROOT = __DIR__;
$DOCROOT = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim($_SERVER['DOCUMENT_ROOT'], '/') : '';
$candidates = [
  $ROOT . '/data',
  $ROOT . '/admin/data',
  dirname($ROOT) . '/data',
  ($DOCROOT ? $DOCROOT . '/data' : '')
];
dbg("ROOT={$ROOT}");
dbg("DOCUMENT_ROOT={$DOCROOT}");
dbg("CANDIDATES:");
foreach ($candidates as $c){ if ($c) dbg(" - {$c} " . (is_dir($c)?'[OK]':'[NO]')); }

$DATA = '';
foreach ($candidates as $c) { if ($c && is_dir($c)) { $DATA = $c; break; } }
dbg("DATA_RESOLVED={$DATA}");

if (!$DATA) { echo "NO_DATA_DIR\n"; exit; }
$BOOKINGS_FILE = $DATA . '/bookings.json';
$DOCS_DIR      = $DATA . '/docs';
$MAILTO_ME     = 'hola@elviejoviajero.es';

/* ===== Utils ===== */
function dmy($iso){
  if (!$iso) return '';
  $d = DateTime::createFromFormat('Y-m-d', $iso);
  return $d ? $d->format('d/m/Y') : $iso;
}
function docs_for($dir) {
  $out = [];
  if (is_dir($dir)) {
    foreach (scandir($dir) as $fn) {
      if ($fn==='.'||$fn==='..') continue;
      $full = $dir . '/' . $fn;
      if (is_file($full)) $out[] = ['full'=>$full,'name'=>$fn, 'size'=>@filesize($full)];
    }
  }
  return $out;
}
function wrap_html($title, $inner){
  $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
  return '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'.
  '<title>'.$title.'</title>'.
  '<style>
    body{margin:0;background:#f6f8f7;font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,"Helvetica Neue",Arial,sans-serif;color:#0a2a1e;}
    .mail{max-width:640px;margin:0 auto;padding:24px;}
    .card{background:#fff;border-radius:14px;box-shadow:0 2px 10px rgba(0,0,0,.06);padding:24px;}
    h1,h2{color:#1E4D3B;margin:0 0 12px}
    p{line-height:1.55;margin:10px 0}
    ul{margin:8px 0 12px 18px}
    .btn{display:inline-block;background:#1E4D3B;color:#fff!important;padding:10px 16px;border-radius:10px;text-decoration:none}
    .foot{margin-top:14px;color:#355e51;font-size:14px}
  </style></head><body><div class="mail"><div class="card">'.$inner.'</div></div></body></html>';
}

/* ===== Mailer (PHPMailer preferente) ===== */
$mailer_ok = false; $mailer_path = '';
$mf_list = [
  $ROOT . '/api/mailer.php',
  dirname($ROOT) . '/api/mailer.php',
  ($DOCROOT ? $DOCROOT . '/api/mailer.php' : '')
];
foreach ($mf_list as $mf) {
  if ($mf && file_exists($mf)) { require_once $mf; $mailer_ok = true; $mailer_path = $mf; break; }
}
dbg("MAILER_FOUND=" . ($mailer_ok ? 'YES' : 'NO') . " at {$mailer_path}");

/* ===== Datos ===== */
if (!file_exists($BOOKINGS_FILE)) { echo "NO_BOOKINGS_FILE at {$BOOKINGS_FILE}\n"; exit; }
$json = file_get_contents($BOOKINGS_FILE);
$data = json_decode($json, true);
if (!$data || !isset($data['bookings'])) { echo "BAD_JSON\n"; dbg($json); exit; }

$today = new DateTime('today');
$sent7=0; $sent24=0; $sent48=0;

foreach ($data['bookings'] as &$b) {
  $id = intval($b['id'] ?? 0);
  $name = trim($b['client'] ?? '');
  $email = trim($b['email'] ?? '');
  $dest = trim($b['destination'] ?? '');
  $startISO = trim($b['start_date'] ?? '');
  if ($id<=0 || $email==='' || $startISO==='') continue;
  $start = DateTime::createFromFormat('Y-m-d', $startISO);
  if (!$start) continue;

  $d7 = (clone $start)->modify('-7 days');
  $d2 = (clone $start)->modify('-2 days');
  $d1 = (clone $start)->modify('-1 day');

  /* ===== 7 días ===== */
  if ($today->format('Y-m-d') === $d7->format('Y-m-d')) {
    $subject = "¡En 7 días te vas a {$dest}! ✈️";
    $inner = "<h2>¡Falta una semana para tu viaje a <strong>".htmlspecialchars($dest)."</strong>! 🗺️✨</h2>
      <p>Hola ".htmlspecialchars($name).",</p>
      <p>Mini recordatorio:</p>
      <ul>
        <li>Documentación al día (DNI/pasaporte)</li>
        <li>Seguros y tarjetas</li>
        <li>Vuelos y horarios actualizados</li>
        <li>Traslados si aplica</li>
      </ul>
      <p>Si necesitas ajustes, escríbenos a <a href='mailto:hola@elviejoviajero.es'>hola@elviejoviajero.es</a> o por WhatsApp.</p>
      <p class='foot'>Un saludo,<br>El equipo de El Viejo Viajero 🕵🏽‍♂️</p>";
    $html = wrap_html($subject, $inner);
    $text = "Hola {$name}\n\n¡Falta una semana para tu viaje a {$dest}! 🗺️✨\n- Documentación\n- Seguros\n- Vuelos\n- Traslados\n\nSi necesitas ajustes, hola@elviejoviajero.es\n\nUn saludo,\nEl Viejo Viajero";
    $ok=false;
    if ($mailer_ok && function_exists('get_mailer')) {
      $m = get_mailer(); $m->Subject=$subject; $m->msgHTML($html); $m->AltBody=$text; $m->addAddress($email,$name); $ok=$m->send();
      dbg("7d: mailer=get_mailer sent=" . ($ok?'YES':'NO'));
    } elseif ($mailer_ok && function_exists('send_mail_html')) {
      $ok = send_mail_html($email,$subject,$html,$text); dbg("7d: mailer=send_mail_html sent=" . ($ok?'YES':'NO'));
    } else {
      $headers="Content-Type: text/html; charset=UTF-8\r\nFrom: El Viejo Viajero <noreply@elviejoviajero.es>\r\n";
      $ok = mail($email,'=?UTF-8?B?'.base64_encode($subject).'?=',$html,$headers); dbg("7d: mailer=mail() sent=" . ($ok?'YES':'NO'));
    }
    if ($ok) $sent7++;
  }

  /* ===== 48 h (interno) ===== */
  if ($today->format('Y-m-d') === $d2->format('Y-m-d')) {
    $subject="⏰ En 48 h viaja {$name} ({$dest})";
    $inner="<h2>Recordatorio interno</h2>
      <p><strong>{$name}</strong> (ID {$id}) inicia viaje a <strong>".htmlspecialchars($dest)."</strong> el <strong>".dmy($startISO)."</strong>.</p>
      <p>Prepara check-in y documentación.</p>";
    $html = wrap_html($subject, $inner);
    $text=strip_tags(str_replace(['<br>','<br/>','<br />'],"\n",$inner));
    $ok=false;
    if ($mailer_ok && function_exists('get_mailer')) {
      $m=get_mailer(); $m->Subject=$subject; $m->msgHTML($html); $m->AltBody=$text; $m->addAddress($MAILTO_ME,'EVV'); $ok=$m->send();
      dbg("48h: mailer=get_mailer sent=" . ($ok?'YES':'NO'));
    } elseif ($mailer_ok && function_exists('send_mail_html')) {
      $ok = send_mail_html($MAILTO_ME,$subject,$html,$text); dbg("48h: mailer=send_mail_html sent=" . ($ok?'YES':'NO'));
    } else {
      $headers="Content-Type: text/html; charset=UTF-8\r\nFrom: El Viejo Viajero <noreply@elviejoviajero.es>\r\n";
      $ok = mail($MAILTO_ME,'=?UTF-8?B?'.base64_encode($subject).'?=',$html,$headers); dbg("48h: mailer=mail() sent=" . ($ok?'YES':'NO'));
    }
    if ($ok) $sent48++;
  }

  /* ===== 24 h (cliente + adjuntos) ===== */
  if ($today->format('Y-m-d') === $d1->format('Y-m-d')) {
    $docs = docs_for($DOCS_DIR . '/' . $id);
    $docsHtml=''; $docsText=''; $attachInfo=[];
    $MAX_SUM = 8 * 1024 * 1024; // 8MB límite recomendado total adjuntos
    $sum = 0;
    if ($docs) {
      $docsHtml = "<p><strong>Tu documentación adjunta:</strong></p>";
      foreach ($docs as $f){
        $docsHtml .= "<p style='margin:6px 0'>📎 ".htmlspecialchars($f['name'])."</p>";
        $docsText .= "• ".$f['name']."\n";
        $sum += intval($f['size'] ?? 0);
        $attachInfo[] = $f;
      }
      $docsText .= "\n";
    }
    dbg("24h: docs_dir={$DOCS_DIR}/{$id} files=" . count($attachInfo) . " size_total=" . $sum);

    $subject="¡Mañana empieza tu viaje a {$dest}!";
    $inner = "<h2>¡Mañana empieza tu viaje a <strong>".htmlspecialchars($dest)."</strong>! 😍✈️</h2>
      <p>Hola ".htmlspecialchars($name).",</p>
      <p><strong>Últimos checks rápidos:</strong></p>
      <ul>
        <li>Check-in de vuelos y tarjetas de embarque</li>
        <li>Documento de identidad/pasaporte</li>
        <li>Dinero/tarjetas y seguro de viaje</li>
        <li>Teléfono cargado y reservas a mano</li>
      </ul>
      {$docsHtml}
      <p>Si necesitas <strong>cualquier cosa de última hora</strong>, escríbenos a <a href='mailto:hola@elviejoviajero.es'>hola@elviejoviajero.es</a> o por WhatsApp. ¡Estamos atentos! 💬</p>
      <p>Gracias por confiar en <strong>El Viejo Viajero</strong>. ¡Buen viaje!<br>Estaremos encantados de volver a vernos pronto 🙂</p>
      <p class='foot'>Un saludo,<br>El equipo de El Viejo Viajero 🕵🏽‍♂️</p>";
    $html = wrap_html($subject, $inner);
    $text = "Hola {$name}\n\n¡Mañana empieza tu viaje a {$dest}! 😍✈️\n\n"
      ."Últimos checks rápidos:\n- Check-in\n- Documento de identidad\n- Dinero/tarjetas\n- Teléfono cargado\n\n"
      .($docs ? "Tu documentación adjunta:\n{$docsText}" : '')
      ."Si necesitas cualquier cosa de última hora, escríbenos a hola@elviejoviajero.es.\n\n"
      ."Gracias por confiar en El Viejo Viajero. ¡Buen viaje!\nEstaremos encantados de volver a vernos pronto :)\n\n"
      ."Un saludo,\nEl equipo de El Viejo Viajero 🕵🏽‍♂️\n";

    $ok=false; $mode='';
    if ($mailer_ok && function_exists('get_mailer')) {
      $m = get_mailer(); $m->Subject=$subject; $m->msgHTML($html); $m->AltBody=$text; $m->addAddress($email,$name);
      $mode='get_mailer';
      // Adjunta si no excede MAX_SUM, si excede, no adjunta y lo indica
      if ($attachInfo && $sum <= $MAX_SUM) {
        foreach ($attachInfo as $f) { $m->addAttachment($f['full'], $f['name']); }
        dbg("24h: attaching " . count($attachInfo) . " files");
      } else if ($attachInfo) {
        dbg("24h: NOT attaching (total size > 8MB)");
      }
      $ok = $m->send();
    } elseif ($mailer_ok && function_exists('send_mail_html')) {
      $mode='send_mail_html'; $ok = send_mail_html($email,$subject,$html,$text);
    } else {
      $mode='mail()'; $headers="Content-Type: text/html; charset=UTF-8\r\nFrom: El Viejo Viajero <noreply@elviejoviajero.es>\r\n";
      $ok = mail($email,'=?UTF-8?B?'.base64_encode($subject).'?=',$html,$headers);
    }
    dbg("24h: mailer=" . $mode . " sent=" . ($ok?'YES':'NO'));
    if ($ok) $sent24++;
  }
}

echo "OK 7d=$sent7 24h=$sent24 48h=$sent48\n";
