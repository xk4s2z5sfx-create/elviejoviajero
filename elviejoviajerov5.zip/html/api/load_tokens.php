
<?php
header('Content-Type: application/json; charset=UTF-8');
$dir = dirname(__DIR__) . '/data';
$file = $dir . '/review_tokens.json';
if (!file_exists($file)) { echo json_encode(['tokens'=>[]], JSON_UNESCAPED_UNICODE); exit; }
$raw = file_get_contents($file);
if ($raw === false) { echo json_encode(['tokens'=>[]], JSON_UNESCAPED_UNICODE); exit; }
echo $raw;
