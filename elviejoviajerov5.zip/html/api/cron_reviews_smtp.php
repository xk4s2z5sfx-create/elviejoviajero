<?php
// /api/cron_reviews.php
// Envia recordatorios diarios (01:00) con enlace de reseña una vez pasada la fecha de vuelta.

date_default_timezone_set('Europe/Madrid');

$CRON_SECRET = 'UEpdWBph5eRZ6o'; // cámbialo si quieres proteger la URL del cron (?secret=...)
$BASE        = 'https://elviejoviajero.es';

// Seguridad opcional del cron
if ($CRON_SECRET !== '') {
  $secret = isset($_GET['secret']) ? $_GET['secret'] : '';
  if ($secret !== $CRON_SECRET) { http_response_code(403); echo "DENIED"; exit; }
}

$today = new DateTime('today');
$dir   = dirname(__DIR__) . '/data';
$file  = $dir . '/bookings.json';
if (!file_exists($file)) { echo "NO_BOOKINGS"; exit; }

$data = json_decode(file_get_contents($file), true);
if (!$data || !isset($data['bookings'])) { echo "BAD_JSON"; exit; }

// Prepara mailer SMTP si existe
$mailer_loaded = false;
$send_html = null;
$mailerPath = __DIR__ . '/mailer.php';
if (file_exists($mailerPath)) {
  require_once $mailerPath;
  if (function_exists('send_mail_html')) {
    $send_html = 'smtp';
    $mailer_loaded = true;
  }
}

$sent = 0;

foreach ($data['bookings'] as &$b) {
  if (!empty($b['review_done'])) continue;
  if (empty($b['start_date']) || empty($b['nights'])) continue;

  try { $start = new DateTime($b['start_date']); } catch (Exception $e) { continue; }
  $return = clone $start; $return->modify('+' . intval($b['nights']) . ' days');

  // Aún no ha vuelto
  if ($today < $return) continue;

  // Ya enviamos hoy
  if (!empty($b['last_sent']) && $b['last_sent'] === $today->format('Y-m-d')) continue;

  $to    = isset($b['email']) ? trim($b['email']) : '';
  if (!$to) continue;

  $name  = isset($b['client']) ? trim($b['client']) : '';
  $dest  = isset($b['destination']) ? trim($b['destination']) : '';
  $token = isset($b['token']) ? trim($b['token']) : '';
  if (!$token) continue;

  $link = $BASE . '/opiniones/index.php?t=' . urlencode($token);

  // ---- Plantilla unificada (HTML + texto) ----
  $subject = '¿Nos dejas tu reseña? ✍️ El Viejo Viajero';

  $nombreSeguro  = $name !== '' ? '<strong>'.htmlspecialchars($name).'</strong>' : '';
  $destinoSeguro = $dest !== '' ? '<strong>'.htmlspecialchars($dest).'</strong>' : '';

  $bodyHtml  = '<p>¡Hola'.($nombreSeguro ? ' '.$nombreSeguro : '').'!</p>';
  $bodyHtml .= '<p>Espero que tu viaje a '.($destinoSeguro ? $destinoSeguro : '<strong>tu destino</strong>').' fuera genial. ';
  $bodyHtml .= 'Nos ayudarías mucho dejando tu reseña:</p>';
  $bodyHtml .= '<p><a href="'.htmlspecialchars($link).'" style="display:inline-block;background:#1E4D3B;color:#fff;padding:12px 18px;border-radius:10px;text-decoration:none;font-size:16px;">💬 Escribir reseña</a></p>';
  $bodyHtml .= '<p>Si por algún motivo tu experiencia no fue la esperada, puedes escribirnos a ';
  $bodyHtml .= '<a href="mailto:hola@elviejoviajero.es">hola@elviejoviajero.es</a> ';
  $bodyHtml .= 'o contactarnos por <a href="https://wa.me/34614451169" target="_blank">WhatsApp</a>. ';
  $bodyHtml .= 'Nos encantará conocer tu opinión para seguir mejorando cada día.</p>';
  $bodyHtml .= '<p>Gracias por confiar en <strong>El Viejo Viajero</strong> 🙌<br>';
  $bodyHtml .= 'Estaremos encantados de acompañarte en tu próxima aventura ✈️</p>';
  $bodyHtml .= '<p>Un saludo,<br><strong>El equipo de El Viejo Viajero</strong> 🕵🏽‍♂️</p>';

  $bodyText  = '¡Hola'.($name!=='' ? ' '.$name : '')."!\\n\\n";
  $bodyText .= 'Espero que tu viaje a '.($dest!=='' ? $dest : 'tu destino').' fuera genial. ';
  $bodyText .= "Nos ayudarías mucho dejando tu reseña:\\n{$link}\\n\\n";
  $bodyText .= "Si por algún motivo tu experiencia no fue la esperada, puedes escribirnos a hola@elviejoviajero.es ";
  $bodyText .= "o contactarnos por WhatsApp (+34 614 451 169). Nos encantará conocer tu opinión para seguir mejorando.\\n\\n";
  $bodyText .= "Gracias por confiar en El Viejo Viajero 🙌\\n";
  $bodyText .= "Estaremos encantados de acompañarte en tu próxima aventura ✈️\\n\\n";
  $bodyText .= "Un saludo,\\nEl equipo de El Viejo Viajero 🕵🏽‍♂️";

  $ok = false;

  if ($mailer_loaded && $send_html === 'smtp') {
    // Enviar con SMTP
    try {
      $ok = send_mail_html($to, $subject, $bodyHtml, $bodyText);
    } catch (Throwable $e) {
      $ok = false;
    }
  } else {
    // Fallback a mail() si no hay mailer
    $headers  = "MIME-Version: 1.0\\r\\n";
    $headers .= "Content-type: text/html; charset=UTF-8\\r\\n";
    $headers .= "From: El Viejo Viajero <noreply@elviejoviajero.es>\\r\\n";
    $ok = @mail($to, '=?UTF-8?B?'.base64_encode($subject).'?=', $bodyHtml, $headers);
  }

  if ($ok) {
    $b['last_sent']  = $today->format('Y-m-d');
    $b['sent_count'] = isset($b['sent_count']) ? intval($b['sent_count'])+1 : 1;
    $sent++;
  }
}

file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
echo "SENT:" . $sent;
