<?php
// /api/smtp_probe.php — prueba SMTP directa usando mailer.php (no requiere formulario)
header('Content-Type: text/plain; charset=UTF-8');
date_default_timezone_set('Europe/Madrid');

$to = isset($_GET['to']) ? $_GET['to'] : 'hola@elviejoviajero.es';
$from_email = 'noreply@elviejoviajero.es';
$from_name  = 'El Viejo Viajero';

$subject = "SMTP PROBE ".date('Y-m-d H:i:s');
$html = "<p>Esto es una prueba SMTP directa desde smtp_probe.</p>";
$text = "Esto es una prueba SMTP directa desde smtp_probe.\n";

$mp = __DIR__ . '/mailer.php';
if (!file_exists($mp)) { http_response_code(500); echo "ERROR: falta /api/mailer.php"; exit; }
require_once $mp;
if (!function_exists('send_mail_html')) { http_response_code(500); echo "ERROR: mailer sin send_mail_html"; exit; }

$opts = ['from_email'=>$from_email,'from_name'=>$from_name];
$ok = @send_mail_html($to, $subject, $html, $text, $opts);
echo $ok ? "OK" : "ERROR";
