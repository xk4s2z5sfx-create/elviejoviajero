<?php
echo password_hash('a47427798G.', PASSWORD_BCRYPT);
?>