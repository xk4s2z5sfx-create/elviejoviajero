<?php
// enviar.php — contacto con plantilla HTML bonita (interno)
header('Content-Type: text/plain; charset=UTF-8');

// ===== Config =====
$DESTINO    = 'hola@elviejoviajero.es';
$FROM_EMAIL = 'noreply@elviejoviajero.es';
$FROM_NAME  = 'El Viejo Viajero';

function val($k, $max=400){
  $v = isset($_POST[$k]) ? trim($_POST[$k]) : '';
  return mb_substr($v, 0, $max, 'UTF-8');
}
function h($s){ return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo 'ERROR: method not allowed'; exit; }

// Honeypot (no devolver OK para no confundir al front)
if (!empty($_POST['website'])) { http_response_code(200); echo 'BOT'; exit; }

$nombre   = val('nombre',   120);
$email    = val('email',    180);
$telefono = val('telefono',  40);
$mensaje  = val('mensaje', 4000);

if ($nombre==='' || $email==='' || $telefono==='' || $mensaje==='') {
  http_response_code(400); echo 'ERROR: faltan campos'; exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  http_response_code(400); echo 'ERROR: email inválido'; exit;
}

// ===== Subject
$subject = $nombre . ' — Nuevo contacto desde la web';

// ===== HTML Template (inlined styles para mejor compatibilidad)
$brand  = '#1E4D3B';
$accent = '#C47A3C';
$ink    = '#1c2a27';
$muted  = '#6b7a76';
$box    = '#ffffff';
$bg     = '#faf9f5';

$ip  = $_SERVER['REMOTE_ADDR'] ?? '';
$ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
$ts  = date('Y-m-d H:i');

// CTA links
$mailto = 'mailto:'.rawurlencode($email).'?subject='.rawurlencode('Re: El Viejo Viajero');
$tel    = 'tel:'.preg_replace('/\s+/', '', $telefono);
$wa     = 'https://wa.me/'.preg_replace('/\D+/', '', $telefono);

$mensaje_html = nl2br(h($mensaje));

$html = <<<HTML
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="x-apple-disable-message-reformatting">
<title>Nuevo contacto</title>
</head>
<body style="margin:0;padding:0;background:{$bg};font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;line-height:1.45;color:{$ink}">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:{$bg};padding:24px 0">
    <tr>
      <td align="center">
        <table role="presentation" width="640" cellspacing="0" cellpadding="0" style="max-width:640px;background:{$box};border-radius:14px;box-shadow:0 2px 10px rgba(0,0,0,.04)">
          <tr>
            <td style="background:{$brand};border-radius:14px 14px 0 0;padding:18px 22px;color:#fff;font-weight:800;font-size:20px">
              El Viejo Viajero
            </td>
          </tr>
          <tr>
            <td style="padding:22px">
              <h1 style="margin:0 0 8px;font-size:22px;color:{$brand}">{$nombre} — Nuevo contacto desde la web</h1>
              <p style="margin:0;color:{$muted}">Recibido el {$ts}</p>

              <div style="margin:18px 0;padding:14px;border:1px solid #eef0ee;border-radius:12px">
                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="font-size:15px">
                  <tr>
                    <td style="padding:6px 0;width:140px;color:{$muted}">Nombre</td>
                    <td style="padding:6px 0;font-weight:600;color:{$ink}">{$nombre}</td>
                  </tr>
                  <tr>
                    <td style="padding:6px 0;color:{$muted}">Email</td>
                    <td style="padding:6px 0"><a href="{$mailto}" style="color:{$brand};text-decoration:none">{$email}</a></td>
                  </tr>
                  <tr>
                    <td style="padding:6px 0;color:{$muted}">Teléfono</td>
                    <td style="padding:6px 0"><a href="{$tel}" style="color:{$brand};text-decoration:none">{$telefono}</a></td>
                  </tr>
                </table>
              </div>

              <h3 style="margin:18px 0 8px;font-size:16px;color:{$ink}">Mensaje</h3>
              <div style="padding:14px;border:1px solid #eef0ee;border-radius:12px;background:#fcfcfb">
                <div style="font-size:15px">{$mensaje_html}</div>
              </div>

              <table role="presentation" cellspacing="0" cellpadding="0" style="margin:20px 0">
                <tr>
                  <td>
                    <a href="{$mailto}" style="display:inline-block;background:{$brand};color:#fff;padding:12px 16px;border-radius:10px;font-weight:700;text-decoration:none">Responder por email</a>
                  </td>
                  <td style="width:10px"></td>
                  <td>
                    <a href="{$wa}" style="display:inline-block;background:{$accent};color:#fff;padding:12px 16px;border-radius:10px;font-weight:700;text-decoration:none">Abrir WhatsApp</a>
                  </td>
                </tr>
              </table>

              <p style="margin:16px 0 0;color:{$muted};font-size:12px">Meta: IP {$ip} · Agente: {$ua}</p>
            </td>
          </tr>
          <tr>
            <td style="padding:14px 22px;border-top:1px solid #f0f0f0;border-radius:0 0 14px 14px;color:{$muted};font-size:13px">
              © {$ts} · El Viejo Viajero — Notificación interna de contacto
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;

$text = "Nuevo contacto desde la web\n\n"
      . "Nombre: {$nombre}\n"
      . "Email: {$email}\n"
      . "Teléfono: {$telefono}\n"
      . "Mensaje:\n{$mensaje}\n\n"
      . "-- El Viejo Viajero";

// ===== SMTP vía mailer.php
$sent = false; $err='';
$mailerPath = __DIR__ . '/api/mailer.php';
if (file_exists($mailerPath)) {
  require_once $mailerPath;
  if (function_exists('send_mail_html')) {
    try {
      $opts = [
        'from_email' => $FROM_EMAIL,
        'from_name'  => $FROM_NAME,
        // al responder, dirigir al cliente
        'reply_to'   => [$email => $nombre],
      ];
      $sent = send_mail_html($DESTINO, $subject, $html, $text, $opts);
    } catch (Throwable $e) { $err = 'Mailer error: '.$e->getMessage(); }
  } else { $err = 'mailer sin send_mail_html'; }
} else { $err = 'no existe /api/mailer.php'; }

if ($sent) { echo 'OK'; }
else { http_response_code(500); echo 'ERROR: ' . ($err ?: 'fallo en mailer'); }
