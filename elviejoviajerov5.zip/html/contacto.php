<?php
$pageTitle = "Contacto | El Viejo Viajero";
include __DIR__ . "/includes/header.php";
?>
<section class="section">
<div class="container">
<h1 style="color:var(--brand); margin:0 0 10px">Contacto</h1>
<p class="note">Cuéntame tu idea y te digo los días recomendados + propuesta base.</p>
<form action="/enviar.php" class="form" id="contactForm" method="post" novalidate>
<div class="input">
<label for="nombre">Nombre</label>
<input id="nombre" maxlength="120" name="nombre" required/>
</div>
<div class="input">
<label for="email">Email</label>
<input id="email" maxlength="180" name="email" required type="email"/>
</div>
<div class="input">
<label for="telefono">Teléfono (WhatsApp)</label>
<input id="telefono" maxlength="40" name="telefono" required type="tel"/>
<small>Con prefijo si no es español (ej. +34 600 000 000)</small>
</div>
<div class="input">
<label for="mensaje">Mensaje</label>
<textarea id="mensaje" maxlength="4000" name="mensaje" placeholder="Fechas aproximadas, nº de personas, estilo de viaje, presupuesto…" required rows="6"></textarea>
</div>
<input autocomplete="off" id="website" name="website" style="display:none" tabindex="-1" type="text"/>
<div class="btns">
<button class="btn" type="submit">Enviar mensaje</button>
<a class="btn alt" href="https://wa.me/34614451169" rel="noopener" target="_blank">Háblanos por WhatsApp</a>
</div>
<div class="success" id="ok">✅ Mensaje enviado. Te responderé por email o WhatsApp en breve.</div>
<div class="error" id="err">⚠️ No se pudo enviar. Si persiste, escríbenos a hola@elviejoviajero.es</div>
</form>
</div>
</section>
<?php include __DIR__ . "/includes/footer.php"; ?>

<script>
document.getElementById('y')?.textContent = new Date().getFullYear();
const form = document.getElementById('contactForm');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(form);
  if(!fd.get('nombre') || !fd.get('email') || !fd.get('telefono') || !fd.get('mensaje')){
    document.getElementById('err').style.display='block';
    return;
  }
  try{
    const r = await fetch(form.action, { method:'POST', body: fd });
    const t = await r.text();
    if (t.trim().startsWith('OK')){
      document.getElementById('ok').style.display='block';
      document.getElementById('err').style.display='none';
      form.reset();
    }else{
      document.getElementById('err').style.display='block';
    }
  }catch(err){
    document.getElementById('err').style.display='block';
  }
});
</script>
<script src="/assets/urlmask.js"></script>
