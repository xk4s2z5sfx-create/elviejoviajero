<?php
$pageTitle = "Opiniones | El Viejo Viajero";
include __DIR__ . '/../includes/header.php';
?>
<section class="section">
<div class="container">
<h1 style="color:var(--brand); margin:0 0 10px">Deja tu reseña</h1>
<p class="note">Tu opinión nos ayuda a mejorar y orienta a otros viajeros. Gracias 🙌</p>
<form action="/api/add_review.php" class="form" id="revForm" method="post" novalidate="">
<div class="input">
<label for="author">Tu nombre</label>
<input id="author" maxlength="120" name="author" required=""/>
</div>
<div class="input">
<label for="text">Tu reseña</label>
<textarea id="text" maxlength="600" name="text" placeholder="Cuenta brevemente tu experiencia (servicio, planificación, etc.)" required="" rows="6"></textarea>
</div>
<input autocomplete="off" id="website" name="website" style="display:none" tabindex="-1" type="text"/>
<input name="token" type="hidden" value="&lt;?php echo htmlspecialchars($token, ENT_QUOTES); ?&gt;"/>
<button class="btn" type="submit">Enviar reseña</button>
<div class="success" id="ok">✅ ¡Gracias! Tu reseña se ha publicado.</div>
<div class="error" id="err">⚠️ No se pudo enviar. Por favor, vuelve a intentarlo más tarde.</div>
</form>
<p class="note" style="margin-top:10px">Si prefieres, también puedes escribirnos por WhatsApp: <a href="https://wa.me/34614451169" rel="noopener" target="_blank">abrir WhatsApp</a>.</p>
</div>
</section>
<script>
    document.getElementById('y').textContent = new Date().getFullYear();
    const f = document.getElementById('revForm');
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(f);
      if(!fd.get('author') || !fd.get('text')){ document.getElementById('err').style.display='block'; return; }
      try{
        const r = await fetch(f.action, { method:'POST', body: fd });
        const t = await r.text();
        if (t.trim().startsWith('OK')){ document.getElementById('ok').style.display='block'; document.getElementById('err').style.display='none'; f.reset(); }
        else { document.getElementById('err').style.display='block'; }
      }catch(err){ document.getElementById('err').style.display='block'; }
    });
  </script>
<script src="/assets/urlmask.js"></script>
<?php include __DIR__ . '/../includes/footer.php'; ?>

<script>
(function(){
  var urlParams = new URLSearchParams(window.location.search);
  var token = urlParams.get('t');
  if(token){
    var field = document.getElementById('tokenField');
    if(field) field.value = token;
  }
})();
</script>
